<?php
namespace Org\Payment\Wft;

class config{
    private $cfg = array(
		//
        'url'=>'https://pay.swiftpass.cn/pay/gateway',
		//
        //'mchId'=>'7552900037',
        'mchId'=>'101500029979',
		//
        //'key'=>'11f4aca52cf400263fdd8faf7a69e007',
        'key'=>'fa1bcb8a901fe47e74b1bc5cd8fecd77',
		//
        'version'=>'2.0',
        'device_info'=>'AND_WAP',
        'mck_app_id'=>'wx5858aafdb8c92975',
        'mch_app_name'=>'香蕉互动',
        'is_raw'=>'0'
       );
    
    public function C($cfgName){
        return $this->cfg[$cfgName];
    }
}
