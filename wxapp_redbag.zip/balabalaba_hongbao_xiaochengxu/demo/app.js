var util = require('./utils/util.js'),
    uk = 'balabalafun_user';

App({
    onLaunch: function () {
        var that = this;

        function login() {
            wx.login({
                success: function (result) {
                    try {
                        if (result.code) {
                            that.get_user();
                            that.globalData.code = result.code;
                        }
                    } catch (e) {
                        console.log(e);
                    } finally {
                        that = null;
                    }
                }
            });
        }

        try {
            that.get_wh();
            wx.authorize({
                scope: 'scope.userInfo',
                success: function () {
                    login();
                },
                fail: function () {
                    that.globalData.msg = '授权失败';
                    that = null;
                }
            });
        } catch (e) {
            console.log(e);
        }
    },
    get_user: function () {
        var that = this;

        function set_(msg) {
            if (that.globalData.times >= that.globalData.can_try_times) {
                that.globalData.msg = '网络繁忙,请重启小程序再试';
                that.to_report('login_fail', {
                    log: msg
                });
            } else {
                that.onLaunch();
                that.globalData.times += 1;
            }
        }

        try {
            wx.getUserInfo({
                withCredentials: true,
                success: function (res) {
                    try {
                        that.login(res, function (result) {
                            try {
                                if (result) {
                                    if (result.error == 0) {
                                        if (result.result.open == 1) {
                                            that.globalData.open = 1;
                                        } else {
                                            that.globalData.open = 0;
                                        }
                                        that.globalData.userInfo = result.result.user;
                                        that.globalData.share = result.result.share;
                                        util.set_storage(uk, result.result.user);
                                        that.to_report('login');
                                    } else if (result.error == 999) {
                                        set_(result.msg);
                                    } else {
                                        that.globalData.msg = '登录失败,请重启小程序再试';
                                    }
                                } else {
                                    set_();
                                }
                            } catch (e) {
                                console.log(e);
                            } finally {
                                that = null;
                            }
                        });
                    } catch (e) {
                        console.log(e);
                    }
                }
            });
        } catch (e) {
            console.log(e);
        }
    },
    login: function (user, callback) {
        var that = this,
            api = util.api_list('login'),
            data = {
                code: that.globalData.code,
                encryptedData: user.encryptedData,
                iv: user.iv,
                rawData: user.rawData,
                signature: user.signature,
                uid: ''
            };
        try {
            util.get_storage(uk, function (res) {
                data.uid = (res && res.id) ? res.id : '';
                util.post_url_data('', api, '', data, '', function (err, result) {
                    try {
                        if (err) {
                            callback(false);
                            console.log(err);
                        } else {
                            callback(result);
                        }
                    } catch (e) {
                        console.log(e);
                    } finally {
                        that = null;
                        api = null;
                        data = null;
                    }
                });
            });
        } catch (e) {
            console.log(e);
        }
    },
    getUserInfo: function () {
        return this.globalData.userInfo ? this.globalData.userInfo : false;
    },
    get_wh: function () {
        var that = this;
        try {
            wx.getSystemInfo({
                success: function (res) {
                    try {
                        that.globalData.system = res;
                        that.globalData.width = res.windowWidth;
                        that.globalData.height = res.windowHeight;
                    } catch (e) {
                        console.log(e);
                    }
                }
            });
        } catch (e) {
            console.log(e);
        }
    },
    to_report: function (key, data) {
        try {
            if (!data) data = {};
            if (this.globalData.userInfo) {
                data.openid = this.globalData.userInfo.openid;
                data.gender = this.globalData.userInfo.gender;
                data.uid = this.globalData.userInfo.id;
            }
            if (this.globalData.system) {
                data.model = this.globalData.system.model;
                data.system = this.globalData.system.system;
                data.version = this.globalData.system.version;
            }
            util.report(key, data);
        } catch (e) {
            console.log(e);
        }
    },
    globalData: {
        userInfo: null,
        code: null,
        openid: null,
        session_key: null,
        msg: null,
        times: 1,
        can_try_times: 3,
        share: null,
        lt: 300,
        width: 0,
        height: 0,
        system: null,
        open: 0
    }
});