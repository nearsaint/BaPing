var app = getApp(),
    util = require('../../utils/util.js');

Page({
    data: {
        loading_status: false,
        loading_message: '加载中...',
        tid: -1,
        winHeight: 0,
        help_list: []
    },
    onLoad: function () {
        this.setData({
            winWidth: app.globalData.width,
            winHeight: app.globalData.height
        });
    },
    onReady: function () {

    },
    onShow: function () {
        var that = this,
            api = util.api_list('help'),
            help_key = 'balabalafun_help_list',
            list,
            time,
            now = Date.parse(new Date()) / 1000;

        function clear() {
            util.hide_loading(that, app.globalData.lt);
            that = null;
            api = null;
            help_key = null;
            list = null;
            time = null;
            now = null;
        }

        try {
            util.show_loading(that);
            util.get_storage(help_key, function (res) {
                if (res) {
                    list = res.list;
                    time = res.time;
                }
                if (list && time && (now - time < 3600)) {
                    that.setData({
                        help_list: list
                    });
                    clear();
                } else {
                    util.post_url_data('', api, '', '', '', function (err, result) {
                        try {
                            if (err) {
                                console.log(err);
                            } else {
                                that.setData({
                                    help_list: result.result
                                });
                                list = {};
                                list.time = now;
                                list.list = [];
                                list.list = result.result;
                                util.set_storage(help_key, list);
                            }
                        } catch (e) {
                            console.log(e);
                        } finally {
                            clear();
                        }
                    });
                }
            });
        } catch (e) {
            console.log(e);
        }
    },
    onReachBottom: function () {

    },
    change: function (e) {
        var that = this,
            index = util.get_data(e, 'id'),
            tid = that.data.tid;
        try {
            if (tid == index) {
                index = -1;
            }
            that.setData({
                tid: index
            });
        } catch (e) {
            console.log(e);
        } finally {
            that = null;
            index = null;
            tid = null;
        }
    },
    get_help: function () {
        try {
            app.to_report('get_help');
        }catch (e){
            console.log(e);
        }
    }
});