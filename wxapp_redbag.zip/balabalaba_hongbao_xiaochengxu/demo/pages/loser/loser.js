var app = getApp(), util = require('../../utils/util.js');

Page({
    data: {
        loading_status: false,
        loading_message: '加载中...',
        list: [],
        id: '',
        refreshing: false,
        loading: false,
        text: '',
        scrollTop: 0,
        playing_id: -1,
        not_ending: true
    },
    onLoad: function (opt) {
        var that = this;
        try {
            app.to_report('get_fail_voice', {redpack_id: that.data.id});
            if (opt.id) {
                that.setData({id: opt.id});
            }
            if (opt.text) {
                that.setData({text: opt.text});
            }
            that.setData({
                winWidth: app.globalData.width,
                winHeight: app.globalData.height
            });
            that.get_list(0, function (list) {
                that.refresh_end(list);
            });
        } catch (e) {
            console.log(e);
        }
    },
    onReachBottom: function () {

    },
    pullDownRefresh: function () {
        var that = this;
        try {
            if (that.data.refreshing == false && that.data.loading_status == true) {
                that.setData({
                    refreshing: true,
                    loading_status: false
                });
                that.refresh_do();
            } else {
                return false;
            }
        } catch (e) {
            console.log(e);
        }
    },
    refresh_do: function () {
        var that = this;
        try {
            that.get_list(0, function (list) {
                that.refresh_end(list);
            });
        } catch (e) {
            console.log(e);
        }
    },
    refresh_end: function (list) {
        var that = this;
        try {
            setTimeout(function () {
                that.setData({
                    list: (list && list.length > 0) ? list : [],
                    scrollTop: 2,
                    not_ending: (list && list.length > 0) ? true : false,
                    refreshing: false
                });
                util.hide_loading(that, app.globalData.lt);
            }, app.globalData.lt + 300);
        } catch (e) {
            console.log(e);
        }
    },
    pullUpLoad: function () {
        var that = this;
        try {
            if (that.data.loading == false && that.data.loading_status == true && that.data.not_ending == true) {
                that.setData({
                    loading: true,
                    loading_status: false
                });
                that.pull_do();
            } else {
                return false;
            }
        } catch (e) {
            console.log(e);
        }
    },
    pull_do: function () {
        var that = this;
        try {
            that.get_list(1, function (list) {
                that.pull_end(list);
            });
        } catch (e) {
            console.log(e);
        }
    },
    pull_end: function (list) {
        var that = this,
            l = that.data.list,
            ne = that.data.not_ending;
        try {
            if (list && list.length > 0) {
                for (var i = 0, il = list.length; i < il; i++) {
                    l.push(list[i]);
                }
            } else {
                ne = false;
            }
            setTimeout(function () {
                that.setData({
                    list: l,
                    not_ending: ne,
                    loading: false
                });
                util.hide_loading(that, app.globalData.lt);
            }, app.globalData.lt);
        } catch (e) {
            console.log(e);
        }
    },
    get_min_id: function () {
        var that = this,
            list = that.data.list,
            mid = 0;
        try {
            if (list && list.length > 0) {
                mid = parseInt(list[0].id);
                for (var i = 0, il = list.length; i < il; i++) {
                    mid = (parseInt(list[i].id) < mid) ? parseInt(list[i].id) : mid;
                }
            }
            return mid;
        } catch (e) {
            console.log(e);
        }
    },
    get_list: function (val, callback) {
        var that = this,
            api = util.api_list('fail_list'),
            data = {
                redpack_id: that.data.id
            };
        try {
            util.show_loading(that);
            data.id = ((val == 1) ? that.get_min_id() : 0);
            util.post_url_data('', api, '', data, '', function (err, res) {
                try {
                    if (err) {
                        console.log(err);
                        callback(false);
                    } else {
                        if (res.error == 0) {
                            (res.result) ? callback(res.result) : callback(false);
                        } else {
                            util.show_loading(that, res.msg);
                            callback(false);
                        }
                    }
                } catch (e) {
                    console.log(e);
                } finally {
                    that = null;
                    api = null;
                    data = null;
                }
            });
        } catch (e) {
            console.log(e);
        }
    },
    voice_play: function (e) {
        var filePath = util.get_data(e, 'voice'),
            that = this,
            playing_id = util.get_data(e, 'id');

        function finish(txt) {
            util.show_loading(that, txt);
            util.hide_loading(that, 300);
            that.setData({playing_id: -1});
            clear();
        }

        function clear() {
            filePath = null;
            that = null;
            playing_id = null;
        }

        try {
            util.show_loading(that);
            wx.downloadFile({
                url: filePath,
                success: function (res) {
                    try {
                        that.setData({
                            loading_message: '播放中',
                            playing_id: playing_id
                        });
                        wx.playVoice({
                            filePath: res.tempFilePath,
                            success: function () {
                            },
                            fail: function () {
                            },
                            complete: function () {
                                finish('播放完成');
                            }
                        });
                    } catch (e) {
                        console.log(e);
                    }
                },
                fail: function () {
                    finish('播放失败');
                },
                complete: function () {
                }
            });
        } catch (e) {
            console.log(e);
        }
    }
});