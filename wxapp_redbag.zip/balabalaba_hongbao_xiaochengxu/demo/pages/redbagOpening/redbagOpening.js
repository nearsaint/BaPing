var app = getApp(),
    util = require('../../utils/util.js'),
    max_time = 25,
    time_fn,
    time = 0;

Page({
    data: {
        loading_status: false,
        loading_message: '登录中...',
        userInfo: {},
        uid: null,
        id: null,
        isSpeaking: false,
        speaking_status: false,
        playing_id: -1,
        status: -1,
        status_msg: '',
        result_list: [],
        text: '',
        money: '',
        total: '',
        quantity: '',
        name: '',
        avatar: '',
        sex: '',
        show: 0,
        upload_time: 0,
        open: 0,
        cnm: null
    },
    onLoad: function (opt) {
        var that = this;
        try {
            if (opt.id) {
                that.setData({id: opt.id});
            }
            if (opt.open) {
                that.setData({open: opt.open});
            }
            that.set_cnm();
            wx.getSetting({
                success: function (res) {
                    if (res['scope.record'] == true) {
                        that.setData({
                            speaking_status: true
                        });
                    } else {
                        wx.authorize({
                            scope: 'scope.record',
                            success: function (res1) {
                                that.setData({
                                    speaking_status: true
                                });
                            }
                        });
                    }
                }
            });
            that.get_user();
            that.setData({
                winWidth: app.globalData.width,
                winHeight: app.globalData.height
            });
        } catch (e) {
            console.log(e);
        }
    },
    onReady: function () {

    },
    onShow: function () {
        if (this.data.show == 1) this.init();
    },
    onHide: function () {
        this.setData({show: 1});
    },
    set_cnm: function () {
        var that = this,
            title = [
            '亲~送福利来了',
            '口快有,口慢无',
            '说对这个口令领悬赏',
            '是时候展示真实的技术了',
            '这个真有意思',
            '这个语音口令好好玩',
            '最难的语音口令,没有之一'
        ];
        try {
            that.setData({
                cnm: title[Math.floor(Math.random() * title.length)]
            });
        } catch (e) {
            console.log(e);
        }
    },
    init: function () {
        var that = this,
            api = util.api_list('detail'),
            data = {
                uid: that.data.userInfo.id,
                redpack_id: that.data.id
            };
        try {
            util.show_loading(that);
            that.setData({
                show: 0
            });
            util.post_url_data('', api, '', data, '', function (err, res) {
                try {
                    if (err) {
                        console.log(err);
                    } else {
                        if (res.error == 0) {
                            that.handle(res.result);
                        } else {
                            that.setData({loading_message: res.msg});
                        }
                    }
                    util.hide_loading(that, app.globalData.lt);
                } catch (e) {
                    console.log(e);
                } finally {
                    that = null;
                    api = null;
                    data = null;
                }
            });
        } catch (e) {
            console.log(e);
        }
    },
    get_user: function () {
        var that = this,
            user = app.getUserInfo();

        function clear() {
            that = null;
            user = null;
        }

        try {
            if (user) {
                util.show_loading(that);
                that.setData({
                    userInfo: user,
                    balance: user.balance
                });
                that.init();
                clear();
            } else {
                if (app.globalData.msg) {
                    util.show_loading(that, app.globalData.msg);
                    clear();
                } else {
                    if (app.globalData.times <= app.globalData.can_try_times) {
                        setTimeout(function () {
                            that.get_user();
                            clear();
                        }, 1000);
                    } else {
                        return false;
                    }
                }
            }
        } catch (e) {
            console.log(e);
        }
    },
    goToShare: function (e) {
        return util.share(e, '', '/pages/redbagOpening/redbagOpening?id=' + this.data.id, app.globalData.share, this.data.userInfo, app.globalData.system);
    },
    onShareAppMessage: function (e) {
        return util.share(e, '', '/pages/redbagOpening/redbagOpening?id=' + this.data.id, app.globalData.share, this.data.userInfo, app.globalData.system);
    },
    onReachBottom: function () {

    },
    goToCash: function () {
        util.nav_to_page('cash');
    },
    goToIndex: function () {
        util.reLaunch('index');
    },
    goToLoser: function () {
        util.nav_to_page('loser', 'id=' + this.data.id + '&text=' + this.data.text);
    },
    voice_start: function () {
        var that = this,
            tempFilePath,
            savedFilePath,
            now = util.get_time(),
            time, rd = {
                redpack_id: that.data.id,
                text: that.data.text
            };

        function clear() {
            that = null;
            tempFilePath = null;
            savedFilePath = null;
            now = null;
            time = null;
            rd = null;
        }

        function error(txt) {
            wx.stopRecord();
            util.hide_loading(that, 0);
            util.show(false, txt);
            clear();
        }

        try {
            if (that.data.isSpeaking == false && that.data.speaking_status == true) {
                if (now - that.data.upload_time >= 3) {
                    that.setData({isSpeaking: true});
                    that.time_fn_start();
                    app.to_report('start_record', rd);
                    wx.startRecord({
                        success: function (res) {
                            time = util.get_time();
                            tempFilePath = res.tempFilePath;
                            that.setData({
                                upload_time: time
                            });
                            if (tempFilePath && time - now >= 1) {
                                wx.saveFile({
                                    tempFilePath: tempFilePath,
                                    success: function (res) {
                                        try {
                                            savedFilePath = res.savedFilePath;
                                            rd.file = res.savedFilePath;
                                            app.to_report('record_success', rd);
                                            that.upload(savedFilePath);
                                        } catch (e) {
                                            console.log(e);
                                        }
                                    },
                                    fail: function (res) {
                                        rd.log = res;
                                        app.to_report('record_fail', rd);
                                        error('录音失败');
                                    }
                                });
                            } else {
                                error('太短了不好');
                            }
                        },
                        fail: function (res) {
                            error('录音的姿势不对');
                        },
                        complete: function (res) {
                            //code
                        }
                    });

                } else {
                    error('操作太频繁了');
                }
            } else {
                if (that.data.speaking_status != true) {
                    error('未授权录音');
                }
                return false;
            }
        } catch (a) {
            console.log(a);
        }
    },
    time_fn_start: function () {
        var that = this;
        time = 0;
        time_fn = setInterval(function () {
            if (time >= max_time) {
                that.time_fn_end();
            } else {
                time += 1;
            }
        }, 1000);
    },
    time_fn_end: function () {
        var that = this;
        clearInterval(time_fn);
        time_fn = null;
        time = 0;
        wx.stopRecord();
        app.to_report('end_record', {
            redpack_id: that.data.id,
            text: that.data.text
        });
    },
    voice_end: function () {
        var that = this;
        try {
            that.time_fn_end();
            if (that.data.isSpeaking == true) {
                that.setData({
                    isSpeaking: false
                });
            } else {
                util.hide_loading(this, 0);
                return false;
            }
        } catch (e) {
            console.log(e);
        }
    },
    voice_play: function (e) {
        var filePath = util.get_data(e, 'voice'),
            that = this,
            playing_id = util.get_data(e, 'id');

        function finish(txt) {
            util.show_loading(that, txt);
            util.hide_loading(that, 300);
            that.setData({playing_id: -1});
            clear();
        }

        function clear() {
            filePath = null;
            that = null;
            playing_id = null;
        }

        try {
            util.show_loading(that);
            wx.downloadFile({
                url: filePath,
                success: function (res) {
                    try {
                        that.setData({
                            loading_message: '播放中',
                            playing_id: playing_id
                        });
                        wx.playVoice({
                            filePath: res.tempFilePath,
                            success: function () {
                            },
                            fail: function () {
                            },
                            complete: function () {
                                finish('播放完成');
                            }
                        });
                    } catch (e) {
                        console.log(e);
                    }
                },
                fail: function () {
                    finish('播放失败');
                },
                complete: function () {
                }
            });
        } catch (e) {
            console.log(e);
        }
    },
    upload: function (file) {
        var that = this, api = util.api_list('upload'), back, result, data;
        var rd = {
            redpack_id: that.data.id,
            text: that.data.text
        };

        function clear() {
            that = null;
            api = null;
            back = null;
            result = null;
            data = null;
        }

        try {
            util.show_loading(that, '玩命抢悬赏中...');
            that.setData({isSpeaking: false});
            if (that.data.loading_status == false) {
                wx.uploadFile({
                    url: api,
                    filePath: file,
                    name: 'file',
                    formData: {
                        redpack_id: that.data.id,
                        uid: that.data.userInfo.id
                    },
                    success: function (res) {
                        back = res.data;
                        data = JSON.parse(back);
                        try {
                            if (data.error == 99) {
                                util.show_loading(that, '您与悬赏擦身而过,请再尝试');
                                util.hide_loading(that, app.globalData.lt);
                            } else {
                                result = data.result;
                                if (data.error == 0) {
                                    util.show_loading(that, '恭喜您,抢到一个悬赏');
                                    rd.mone = result.take_money * 100;
                                    app.to_report('take_redpack_success', rd);
                                } else {
                                    util.show_loading(that, data.msg);
                                    rd.log = data.msg;
                                    rd.match = result.txt;
                                    app.to_report('take_redpack_fail', rd);
                                }
                                that.handle(result);
                            }
                        } catch (e) {
                            console.log(e);
                        }
                    },
                    fail: function (res) {
                        util.show_loading(that, '您与抢悬赏擦身而过,请再尝试');
                        util.hide_loading(that, 1000);
                    },
                    complete: function (res) {
                    }
                });
            } else {
                util.hide_loading(that, 0);
                return false;
            }
        } catch (e) {
            console.log(e);
        }
    },
    handle: function (data) {
        var that = this;
        try {
            that.setData({
                text: data.redpack.txt,
                total: data.redpack.money,
                quantity: data.redpack.quantity,
                avatar: data.redpack.user.avatarUrl,
                name: data.redpack.user.nickname,
                sex: data.redpack.user.gender,
                status: data.has_take,
                status_msg: data.msg,
                money: data.take_money,
                result_list: data.list
            });
            util.hide_loading(that, app.globalData.lt);
        } catch (e) {
            console.log(e);
        }
    },
    change_open: function () {
        try {
            this.setData({
                open: 0
            });
        }catch (e){
            console.log(e);
        }
    }
});
