var app = getApp(),
    util = require('../../utils/util.js');

Page({
    data: {
        loading_status: false,
        loading_message: '加载中...',
        userInfo: {},
        winHeight: 0,
        currentTab: 0,
        get_num: 0,
        get_total: 0,
        get_list: [],
        send_num: 0,
        send_total: 0,
        send_list: []
    },
    onLoad: function () {
        var that = this;
        try {
            that.get_user();
        } catch (e) {
            console.log(e);
        }
    },
    onShow: function () {
        this.init();
    },
    onHide: function () {

    },
    onReachBottom: function () {

    },
    init: function () {
        var that = this,
            api = util.api_list('history');
        try {
            util.show_loading(that);
            util.post_url_data('', api, '', {uid: that.data.userInfo.id}, '', function (err, res) {
                try {
                    if (err) {
                        console.log(err);
                    } else {
                        if (res.error == 0) {
                            that.setData({
                                loading_status: true,
                                get_num: res.result.get_num,
                                get_total: res.result.get_total,
                                get_list: res.result.get_history,
                                send_num: res.result.send_num,
                                send_total: res.result.send_total,
                                send_list: res.result.send_history
                            });
                        } else {
                            util.show_loading(that, res.msg);
                        }
                    }
                    util.hide_loading(that, app.globalData.lt);
                } catch (e) {
                    console.log(e);
                } finally {
                    that = null;
                    api = null;
                }
            });
        } catch (e) {
            console.log(e);
        }
    },
    get_user: function () {
        var that = this,
            user = app.getUserInfo();

        function clear() {
            that = null;
            user = null;
        }

        try {
            if (user) {
                that.setData({
                    userInfo: user,
                    winWidth: app.globalData.width,
                    winHeight: app.globalData.height
                });
                clear();
            } else {
                if (app.globalData.msg) {
                    util.show_loading(that, app.globalData.msg);
                    clear();
                } else {
                    if (app.globalData.times <= app.globalData.can_try_times) {
                        setTimeout(function () {
                            that.get_user();
                            clear();
                        }, 1500);
                    } else {
                        return false;
                    }
                }
            }
        } catch (e) {
            console.log(e);
        }
    },
    bindChange: function (e) {
        try {
            this.change_view(e.detail.current);
        } catch (e) {
            console.log(e);
        }
    },
    swichNav: function (e) {
        var that = this;
        try {
            if (that.data.currentTab === e.target.dataset.current) {
                return false;
            } else {
                that.change_view(e.target.dataset.current);
            }
        } catch (e) {
            console.log(e);
        } finally {
            that = null;
        }
    },
    change_view: function (data) {
        try {
            this.setData({
                currentTab: data
            });
            this.init();
        } catch (e) {
            console.log(e);
        }
    },
    get_detail: function (e) {
        this.go_open(e, 0);
    },
    send_detail: function (e) {
        this.go_open(e, 1);
    },
    go_open: function (e, val) {
        var id = util.get_data(e, 'id'),
            prams;
        try {
            prams = 'id=' + id + ((val == 1) ? '&open=' + app.globalData.open : '');
            util.nav_to_page('redbagOpening', prams);
        } catch (e) {
            console.log(e);
        } finally {
            id = null;
        }
    }
});
