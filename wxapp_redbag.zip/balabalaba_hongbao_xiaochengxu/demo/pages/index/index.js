var app = getApp(),
    util = require('../../utils/util.js'),
    md5 = require('../../utils/md5.js'),
    fn = 2,
    nc = /^[0-9]*[1-9][0-9]*$/,
    tiper_fn,
    reg = /^[\u4E00-\u9FFF]+$/,
    regL = 15;

Page({
    data: {
        loading_status: false,
        loading_message: '登录中...',
        user_info: {},
        money_items: [],
        key_items: [],
        _num: -1,
        money: '',
        text: "",
        num: '',
        sub: '0.00',
        total: '0.00',
        balance: '0.00',
        tiper_status: true,
        tiper_message: '',
        show: 0
    },
    onLoad: function () {
        var that = this;
        try {
            that.get_user();
        } catch (e) {
            console.log(e);
        } finally {
            that = null;
        }
    },
    onShow: function () {
        if (this.data.show == 1) {
            this.get_items();
        }
    },
    onHide: function () {
        this.setData({show: 1});
    },
    onReachBottom: function () {

    },
    get_user: function () {
        var that = this,
            user = app.getUserInfo();

        function clear() {
            that = null;
            user = null;
        }

        try {
            if (user) {
                that.setData({
                    user_info: user,
                    balance: user.balance
                });
                that.get_items();
                clear();
            } else {
                if (app.globalData.msg) {
                    util.show_loading(that, app.globalData.msg);
                    clear();
                } else {
                    if (app.globalData.times <= app.globalData.can_try_times) {
                        setTimeout(function () {
                            that.get_user();
                            clear();
                        }, 1000);
                    } else {
                        return false;
                    }
                }
            }
        } catch (e) {
            console.log(e);
        }
    },
    get_items: function () {
        var that = this,
            api = util.api_list('index'),
            data = {};
        try {
            util.show_loading(that);
            if (that.data.user_info && that.data.user_info.id > 0) {
                data = {
                    uid: that.data.user_info.id
                };
            }
            util.post_url_data('', api, '', data, '', function (err, res) {
                try {
                    if (err) {
                        console.log(err);
                    } else {
                        if (res.error == 0) {
                            if (res.result.user) {
                                that.setData({
                                    balance: res.result.user.balance,
                                    show: 0,
                                    money_items: res.result.money_items,
                                    key_items: res.result.key_items
                                });
                            } else {
                                that.setData({
                                    show: 0,
                                    money_items: res.result.money_items,
                                    key_items: res.result.key_items
                                });
                            }
                        } else {
                            util.show_loading(that, res.msg);
                        }
                    }
                    util.hide_loading(that, app.globalData.lt);
                } catch (e) {
                    console.log(e);
                } finally {
                    that = null;
                    api = null;
                }
            });
        } catch (e) {
            console.log(e);
        }
    },
    load_more: function () {
        app.to_report('get_random_key');
        this.get_items();
    },
    goToHistory: function () {
        util.nav_to_page('history');
    },
    goToHelp: function () {
        util.nav_to_page('help');
    },
    goToCash: function () {
        util.nav_to_page('cash');
    },
    goToShare: function (e) {
        return util.share(e, '', '/pages/index/index', app.globalData.share, this.data.user_info, app.globalData.system);
    },
    onShareAppMessage: function (e) {
        return util.share(e, '', '/pages/index/index', app.globalData.share, this.data.user_info, app.globalData.system);
    },
    change_color: function (e) {
        var index = util.get_data(e, 'money'),
            money = parseFloat(index).toFixed(fn),
            sub = (parseFloat(index * 0.1)).toFixed(fn),
            total = parseFloat(index * 1.1).toFixed(fn);
        try {
            this.setData({
                _num: index,
                money_val: index,
                money: money,
                sub: sub,
                total: total
            });
        } catch (e) {
            console.log(e);
        } finally {
            index = null;
            money = null;
            sub = null;
            total = null;
        }
    },
    change_text: function (e) {
        var txt = util.get_data(e, 'text');
        try {
            this.setData({text: txt});
        } catch (e) {
            console.log(e);
        } finally {
            txt = null;
        }
    },
    bindChange: function (e) {
        var type_ = util.get_data(e, 'type'),
            that = this,
            val = e.detail.value, val_;

        function clear() {
            that = null;
            type_ = null;
            val = null;
            val_ = null;
        }

        try {
            if (type_ == 'money') {
                try {
                    if (val >= 1 && val < 1000) {
                        val_ = val;
                        if (!val) val = 0;
                        var money = parseFloat(val).toFixed(fn),
                            sub = (parseFloat(val) * 0.1).toFixed(fn),
                            total = parseFloat(val * 1.1).toFixed(fn);
                        that.setData({
                            _num: val,
                            money_val: val_,
                            money: money,
                            sub: sub,
                            total: total
                        });
                    } else {
                        if (val < 1) that.set_tiper('金额必须大于 1 元');
                        if (val >= 1000) that.set_tiper('金额必须小于 1000 元');
                    }
                } catch (e) {
                    console.log(e);
                } finally {
                    money = null;
                    sub = null;
                    total = null;
                    clear();
                }
            } else {
                if (type_ == 'num') {
                    var num = parseInt(val);
                    try {
                        if (num <= 0) that.set_tiper('个数必须大于 0 个');
                        if (num > 50) that.set_tiper('个数必须小于 50 个');
                        that.setData({
                            num: num
                        });
                    } catch (e) {
                        console.log(e);
                    } finally {
                        num = null;
                        clear();
                    }
                } else if (type_ == 'text') {
                    try {
                        if (!val) that.set_tiper('请输入口令');
                        if (!reg.test(val)) that.set_tiper('口令必须为中文');
                        if (val.length > regL) that.set_tiper('口令字数不能大于' + regL);
                        that.setData({text: String(val)});
                    } catch (b) {
                        console.log(b);
                    } finally {
                        clear();
                    }
                } else {
                    return false;
                }
            }
        } catch (a) {
            console.log(a);
        }
    },
    onSubmit: function () {
        var that = this,
            text = that.data.text,
            money = that.data.money,
            sub = that.data.sub,
            total = that.data.total,
            num = that.data.num;

        function clear() {
            that = null;
            text = null;
            money = null;
            sub = null;
            total = null;
            num = null;
        }

        function error(txt) {
            util.show(false, txt);
            clear();
        }

        try {
            if (text) {
                if (money && sub && total) {
                    if (num) {
                        if (money >= 1 && money < 1000) {
                            if (num >= 1 && num <= 50) {
                                if (reg.test(text)) {
                                    if (money >= num) {
                                        if (text.length > 0 && text.length <= regL) {
                                            that.make_order(text, money, num);
                                        } else {
                                            error('口令字数不能大于' + regL);
                                        }
                                    } else {
                                        error('每人获得打赏不得低于 1 元');
                                    }
                                } else {
                                    error('口令必须为中文');
                                }
                            } else {
                                if (num <= 0) error('个数必须大于 0 个');
                                if (num > 50) error('个数必须小于 50 个');
                            }
                        } else {
                            error('金额必须大于0并且小于1000');
                        }
                    } else {
                        error('请输入个数');
                    }
                } else {
                    error('请输入金额');
                }
            } else {
                error('请输入口令');
            }
        } catch (e) {
            console.log(e);
        }
    },
    set_tiper: function (msg) {
        var that = this;

        function set_(status, txt) {
            if (status || txt) {
                that.setData({
                    tiper_status: status,
                    tiper_message: txt ? txt : ''
                });
            } else {
                return false;
            }
        }

        function clear() {
            if (that) that = null;
            if (tiper_fn) tiper_fn = null;
        }

        try {
            if (!tiper_fn) {
                set_(false, msg);
                tiper_fn = setTimeout(function () {
                    try {
                        set_(true, '');
                    } catch (e) {
                        console.log(e);
                    } finally {
                        clear();
                    }
                }, 2000);
            } else {
                clear();
                return false;
            }
        } catch (e) {
            console.log(e);
        }
    },
    make_order: function (text, money, num) {
        var that = this,
            api = util.api_list('new'),
            key = 'balabalafun.qw9o',
            data = {
                uid: that.data.user_info.id,
                txt: text,
                money: money,
                num: num,
                sign: md5.md5(md5.md5(that.data.user_info.id + text + money + num) + key)
            },
            rd = {
                txt: text,
                mone: money * 1.1,
                num: num
            };
        try {
            console.log(that.data.user_info.id + text + money + num);
            util.show_loading(that, '提交中...');
            app.to_report('make_order', rd);
            util.post_url_data('', api, '', data, '', function (err, result) {
                if (err) {
                    console.log(err);
                } else {
                    if (result.error == 0) {
                        that.pay(result.result);
                    } else {
                        if (result.error == 1) {
                            that.cancel_pay(result.result.redpack_id);
                        }
                        util.show_loading(that, result.msg);
                    }
                }
                util.hide_loading(that, app.globalData.lt + 500);
            });
        } catch (e) {
            console.log(e);
        }
    },
    pay: function (res) {
        var that = this,
            rd = {
                mone: res.money * 1.1
            };

        function clear() {
            if (that) that = null;
        }

        try {
            if (res.use_balance == 1) {
                util.show_loading(that, '支付成功...');
                rd.redpack_id = res.redpack_id;
                setTimeout(function () {
                    util.nav_to_page('redbagOpening', 'id=' + res.redpack_id + '&open=1');
                }, 500);
                app.to_report('pay_success', rd);
                util.hide_loading(that, 1500);
            } else {
                if (res.timeStamp && res.nonceStr && res.package && res.signType && res.paySign && res.redpack_id) {
                    wx.requestPayment({
                        'timeStamp': res.timeStamp,
                        'nonceStr': res.nonceStr,
                        'package': res.package,
                        'signType': res.signType,
                        'paySign': res.paySign,
                        'success': function (result) {
                            util.show_loading(that, '支付成功...');
                            rd.redpack_id = res.redpack_id;
                            app.to_report('pay_success', rd);
                            setTimeout(function () {
                                util.nav_to_page('redbagOpening', 'id=' + res.redpack_id + '&open=' + app.globalData.open);
                            }, 500);
                        },
                        'fail': function (result) {
                            util.show_loading(that, '支付失败...');
                            rd.log = result;
                            app.to_report('pay_fail', rd);
                            that.cancel_pay(res.redpack_id);
                        },
                        'complete': function () {
                            util.hide_loading(that, 0);
                            clear();
                        }
                    });
                } else {
                    util.show_loading(that, '支付异常,请重试...');
                    util.hide_loading(that, app.globalData.lt);
                    clear();
                }
            }
        } catch (e) {
            console.log(e);
        }
    },
    cancel_pay: function (id) {
        var that = this,
            api = util.api_list('cancel'),
            data = {
                redpack_id: id,
                uid: that.data.user_info.id
            };
        try {
            util.post_url_data('', api, '', data, '', function (err, result) {
                try {
                    if (err) {
                        console.log(err);
                    } else {
                        if (result.error == 0) {
                            util.show_loading(that, '取消订单成功');
                        } else {
                            util.show_loading(that, result.msg);
                        }
                    }
                    util.hide_loading(that, app.globalData.lt);
                } catch (e) {
                    console.log(e);
                } finally {
                    that.get_items();
                    that = null;
                    api = null;
                    data = null;
                }
            });
        } catch (e) {
            console.log(e);
        }
    }
});