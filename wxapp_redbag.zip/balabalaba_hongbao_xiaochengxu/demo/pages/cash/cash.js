var app = getApp(),
    util = require('../../utils/util.js'),
    fn = 2;

Page({
    data: {
        loading_status: false,
        loading_message: '加载中...',
        userInfo: {},
        balance: 0.00,
        money: ''
    },
    onLoad: function (options) {
        this.get_user();
    },
    onReady: function () {

    },
    onShow: function () {
        var that = this,
            api = util.api_list('index');
        try {
            util.show_loading(that);
            util.post_url_data('', api, '', {uid: this.data.userInfo.id}, '', function (err, res) {
                try {
                    if (err) {
                        console.log(err);
                    } else {
                        if (res.error == 0) {
                            that.setData({
                                balance: res.result.user.balance
                            });
                        }
                    }
                    util.hide_loading(that, app.globalData.lt);
                } catch (e) {
                    console.log(e);
                }
            });
        } catch (e) {
            console.log(e);
        }
    },
    get_user: function () {
        var that = this,
            user = app.getUserInfo();

        function clear() {
            that = null;
            user = null;
        }

        try {
            if (user) {
                util.show_loading(that);
                that.setData({
                    userInfo: user,
                    balance: user.balance
                });
                clear();
            } else {
                if (app.globalData.msg) {
                    util.show_loading(that, app.globalData.msg);
                    clear();
                } else {
                    if (app.globalData.times <= app.globalData.can_try_times) {
                        setTimeout(function () {
                            that.get_user();
                            clear();
                        }, 1500);
                    } else {
                        return false;
                    }
                }
            }
        } catch (e) {
            console.log(e);
        }
    },
    goToHelp: function () {
        util.nav_to_page('help');
    },
    input_money: function (e) {
        var that = this,
            m = e.detail.value;
        try {
            if (m) {
                that.setData({
                    money: parseFloat(m).toFixed(fn)
                });
            } else {
                return false;
            }
        } catch (e) {
            console.log(e);
        } finally {
            that = null;
            m = null;
        }
    },
    take_all: function () {
        var that = this,
            m = that.data.balance;
        try {
            if (m && m > 0) {
                that.setData({money: m});
            } else {
                return false;
            }
        } catch (e) {
            console.log(e);
        } finally {
            that = null;
            m = null;
        }
    },
    onSubmit: function () {
        var that = this,
            uid = that.data.userInfo.id,
            money = that.data.money,
            balance = that.data.balance,
            api = util.api_list('get_cash'),
            data = {
                uid: uid,
                money: money
            },
            rd = {
                mone: money
            };

        function clear() {
            that = null;
            uid = null;
            money = null;
            balance = null;
            api = null;
            data = null;
        }

        function error(txt) {
            util.toast(txt, 'loading');
            clear();
        }

        try {
            if (money) {
                if (money >= 1) {
                    if (money <= balance) {
                        util.show_loading(that, '提交中...');
                        app.to_report('cash', rd);
                        util.post_url_data('', api, '', data, '', function (err, res) {
                            util.hide_loading(that, 0);
                            if (err) {
                                console.log(err);
                            } else {
                                if (res.error == 0) {
                                    that.setData({
                                        balance: res.result.balance
                                    });
                                    app.to_report('cash_success', rd);
                                } else {
                                    rd.log = res.msg;
                                    app.to_report('cash_fail', rd);
                                }
                                util.show(false, res.msg);
                            }
                        });
                    } else {
                        error('提现金额不能大于余额');
                    }
                } else {
                    error('提现金额必须大于 1 元');
                }
            } else {
                error('请输入提现金额');
            }
        } catch (e) {
            console.log(e);
        }
    }
});