var ssid,
    key = 'balabalafun_session_id';

function set_storage(k, v) {
    wx.setStorage({
        key: k,
        data: v,
        success: function (res) {
            if (k == key) {
                ssid = v;
            }
        },
        fail: function (res) {
            console.log(res);
        }
    })
}

function get_storage(k, callback) {
    wx.getStorage({
        key: k,
        success: function (res) {
            if (res.data && k == key) {
                ssid = res.data;
            } else {
                callback(res.data);
            }
        },
        fail: function (res) {
            callback(false);
        }
    })
}

function formatTime(date) {
    var year = date.getFullYear(), month = date.getMonth() + 1, day = date.getDate(), hour = date.getHours(), minute = date.getMinutes(), second = date.getSeconds();
    try {
        return [year, month, day].map(formatNumber).join('/') + ' ' + [hour, minute, second].map(formatNumber).join(':');
    } catch (e) {
        console.log(e);
    } finally {
        year = null;
        month = null;
        day = null;
        hour = null;
        minute = null;
        second = null;
    }
}

function formatNumber(n) {
    try {
        n = n.toString();
        return n[1] ? n : '0' + n;
    } catch (e) {
        console.log(e);
    }
}

function api_list(val){
    var api_host = 'https://vrp.balabalafun.cn/index.php/Home'; //api use
    //var api_host = 'https://vrpdev.balabalafun.cn/index.php/Home'; //test
    try{
        switch(val){
            case 'history': return api_host +'/Api/all_history';break;
            case 'index': return api_host + '/Api/index_list'; break;
            case 'create': return api_host + '/Api/index_list'; break;
            case 'login': return api_host + '/Login/login'; break;
            case 'upload': return api_host + '/Api/take_redpack'; break;
            case 'help': return api_host + '/Api/faq'; break;
            case 'new': return api_host + '/Api/new_redpack';break;
            case 'detail': return api_host + '/Api/redpack_detail';break;
            case 'cancel': return api_host + '/Api/cancelRedpack';break;
            case 'get_cash': return api_host + '/Api/cashout';break;
            case 'fail_list': return api_host + '/Api/get_fail_voice';break;
            default:return false;break;
        }
    } catch (e) {
        console.log(e);
    } finally {
        api_host = null;
    }
}

function post_url_data(header, url, method, data, dataType, callback) {
    try {
        if (!header) {
            header = {};
            if (!ssid) get_storage(key, function (res) {
            });
            header['content-type'] = 'application/x-www-form-urlencoded';
            if (ssid) header['Cookie'] = ssid;
        }
        if (url) {
            wx.getNetworkType({
                success: function (res) {
                    if (res.networkType && res.networkType != 'none') {
                        wx.request({
                            url: url,
                            data: data ? data : {},
                            method: method ? method : 'POST',
                            header: header,
                            dataType: dataType ? dataType : 'json',
                            success: function (res) {
                                var cookie, session;
                                try {
                                    if (res) {
                                        if (res.statusCode == 200) {
                                            if (res.header['Set-Cookie']) {
                                                cookie = res.header['Set-Cookie'].split(" ");
                                                if (cookie[0] && cookie[0].indexOf('PHPSESSID=') > -1) {
                                                    session = cookie[0].split(";");
                                                    if (session[0] && session[0].indexOf('PHPSESSID=') > -1) {
                                                        if (ssid != session[0]) {
                                                            ssid = session[0];
                                                            set_storage(key, ssid);
                                                        }
                                                    }
                                                }
                                            }
                                            callback('', res.data);
                                        } else {
                                            callback(res.errMsg, '');
                                        }
                                    } else {
                                        callback('post error', '');
                                    }
                                } catch (e) {
                                    console.log(e);
                                } finally {
                                    cookie = null;
                                    session = null;
                                }
                            },
                            fail: function () {
                                try {
                                    console.log(url);
                                    show(false, '请检查网络链接');
                                    callback('please check your network!', '');
                                } catch (e) {
                                    console.log(e);
                                }
                            },
                            complete: function () {

                            }
                        });
                    } else {
                        show(false, '请检查网络链接');
                        callback('please check your network!', '');
                    }
                },
                fail: function (res) {
                    show(false, '请检查网络链接');
                    callback('please check your network!', '');
                }
            });
        } else {
            show(false, '网络链接失败');
            callback('url error', '');
        }
    } catch (e) {
        console.log(e);
    }
}

function show_loading() {
    wx.showToast({
        title: 'loading',
        icon: 'loading',
        duration: 500
    });
}

function hide_loading() {
    wx.hideToast();
}

function get_data(e, key) {
    var data = e.currentTarget.dataset[key];
    try {
        return data != null ? data : null;
    } catch (e) {
        console.log(e);
    } finally {
        data = null;
    }
}

function check_prams(url, prams) {
    try {
        if (prams) {
            return url + '?' + prams;
        } else {
            return url
        }
    } catch (e) {
        console.log(e);
    }
}

function nav_to_page(page, prams) {
    var url = '../' + page + '/' + page;
    url = check_prams(url, prams);
    try {
        wx.navigateTo({
            url: url
        });
    } catch (e) {
        console.log(e);
    } finally {
        url = null;
    }
}

function reLaunch(page, prams) {
    var url = '../' + page + '/' + page;
    url = check_prams(url, prams);
    try {
        wx.reLaunch({
            url: url
        });
    } catch (e) {
        console.log(e);
    } finally {
        url = null;
    }
}

function show(status, msg) {
    try {
        wx.showModal({
            title: '提示',
            content: msg,
            showCancel: status
        });
    } catch (e) {
        console.log(e);
    }
}

function toast(t, i, time) {
    try {
        wx.showToast({
            title: t,
            icon: i ? i : 'success',
            duration: time ? time : 1000
        })
    } catch (e) {
        console.log(e);
    }
}

function get_time() {
    return (Date.parse(new Date()) / 1000);
}

function share(e, t, p, data, user, system) {
    var rd;
    try {
        t = t ? t : share_title(data);
        rd = {
            title: t,
            page: p

        };
        if (system) {
            rd.model = system.model;
            rd.system = system.system;
            rd.version = system.version;
        }
        if (user) {
            rd.openid = user.openid;
            rd.gender = user.gender;
            rd.uid = user.id;
        }
        if (e && t && p) {
            if (e.from === 'button') {
                // 来自页面内转发按钮
                // console.log(e.target);
            }
            report('share', rd);
            return {
                title: t,
                path: p,
                success: function (res) {
                    report('share_success', rd);
                },
                fail: function (res) {
                    rd.log = res;
                    report('share_fail', rd);
                }
            };
        } else {
            return false;
        }
    } catch (e) {
        console.log(e);
    }
}

function base64_encode(data) {
    try {
        return wx.arrayBufferToBase64(data);
    } catch (e) {
        console.log(e);
    }
}

function base64_decode(base64) {
    try {
        return wx.base64ToArrayBuffer(base64);
    } catch (e) {
        console.log(e);
    }
}

function share_title(data) {
    var title = [
        '亲~送福利来了',
        '口快有,口慢无',
        '说对这个口令领悬赏',
        '是时候展示真实的技术了',
        '这个真有意思',
        '这个语音口令好好玩',
        '最难的语音口令,没有之一'
    ];
    try {
        if (data) title = data;
        return title[Math.floor(Math.random() * title.length)];
    } catch (e) {
        console.log(e);
    } finally {
        title = null;
    }

}


function page_show_loading(e, msg) {
    msg = msg ? msg : '加载中...';
    e.setData({
        loading_status: false,
        loading_message: msg
    });
}

function page_hide_loading(e, t) {
    t = (t >= 0) ? t : 2000;
    setTimeout(function () {
        e.setData({
            loading_status: true,
            loading_message: ''
        });
    }, t);
}

function report(key, data) {
    wx.reportAnalytics(key, data);
}


module.exports = {
    formatTime: formatTime,
    post_url_data: post_url_data,
    show_loading: page_show_loading,
    hide_loading: page_hide_loading,
    get_data: get_data,
    nav_to_page: nav_to_page,
    show: show,
    toast: toast,
    get_time: get_time,
    share: share,
    api_list: api_list,
    reLaunch: reLaunch,
    base64_encode: base64_encode,
    base64_decode: base64_decode,
    set_storage: set_storage,
    get_storage: get_storage,
    report: report
};