<?php
return array(
	//'配置项'=>'配置值'
    'CONFIG_NAME'=>'config',
    'DEFAULT_MODULE'    =>  'Home',  // 默认模块
    'MULTI_MODULE'      =>  true, // 是否允许多模块 如果为false 则必须设置 DEFAULT_MODULE
    'MODULE_DENY_LIST'  =>  array('Common','Runtime'),
    'LOG_RECORD' => true,
    'LOG_LEVEL'  =>'EMERG,ALERT,CRIT,ERR',
    'DB_DEPLOY_TYPE'    =>  1, //是否启用分布式
    'DB_RW_SEPARATE'    =>  false, //是否启用智能读写分离
//product mode
    'DB_TYPE'           =>  'mysql', //数据库类型
    'DB_HOST'           =>  '10.66.219.141', //服务器地址
    'DB_NAME'           =>  'voice_redpack', //数据库名
    'DB_USER'           =>  'root', //用户名
    'DB_PWD'            =>  'mos2017%*&UI', //密码
    'DB_PREFIX' => '',
    'DB_PARAMS' => array('persist' => true),
    'DB_DEBUG'=>false,
    'TMPL_CACHE_ON'         =>  true,
    'URL_PARAMS_BIND'       =>  true,
    'SESSION_AUTO_START'    =>  true,    // 是否自动开启Session
////    //以下使用Redis作为共享SESSION使用，在测试 环境请注释
    'SESSION_TYPE'            =>  'Redis',    //session类型
    'SESSION_PERSISTENT'    =>  1,        //是否长连接(对于php来说0和1都一样)
    'SESSION_CACHE_TIME'    =>  3600,        //连接超时时间(秒)
    'SESSION_EXPIRE'        =>  3600,        //session有效期(单位:秒) 0表示永久缓存
    'SESSION_PREFIX'        =>  'sess_',        //session前缀
    'SESSION_REDIS_HOST'    =>  '127.0.0.1', //分布式Redis,默认第一个为主服务器
    'SESSION_REDIS_PORT'    =>  '6379',           //端口,如果相同只填一个,用英文逗号分隔
////    'SESSION_REDIS_AUTH'    =>  'redis',    //Redis auth认证(密钥中不能有逗号),如果相同只填一个,用英文逗号分隔
    'TMPL_PARSE_STRING'  =>array(
        '__PUBLIC__' => '/Public',
         '__JS__'     => '/Public/JS/',
         '__UPLOAD__' => '/Uploads',
    ),
    'DATA_CACHE_TYPE'   =>  'Redis',
    'DATA_CACHE_PREFIX' =>  'cache_',
    'REDIS_HOST'        =>  '127.0.0.1',
    'REDIS_PORT'        =>  '6379',
    'REDIS_DATABASE'        =>  0,
    'UPYUN_CONFIG'=>array(
        'bucket'=>'balabalafun',
        'operator'=>'herman',
        'passwd'=>'balabala',
        'save_key'=>'/{year}/{mon}/{day}/upload_{random32}{.suffix}',
        'allow-file-type'=>'jpg,jpeg,png',
        'host'=>'http://upyunoss.balabalafun.cn'
    ),

//    'WECHAT_APPNAME'    =>  'balabala_fun',
//    'WECHAT_APPID'      =>  'wx5858aafdb8c92975',
//    'WECHAT_APPSECRET'  =>  'cdc51f7bb842e438d28b6ce16989fa56',
    'WECHAT_APPNAME'    =>  'balabalaHD',
    'WECHAT_APPID'      =>  'wx818cff0f6be342fc',
    'WECHAT_APPSECRET'  =>  'bff4375cf08703725c5de7fdeccbbf45',
    'WECHAT_TOKEN'=>'nNhC2I7rSJxoN1JDo',
    'WECHAT_ENCODINGAESKEY'=>'nNhC2I7rSJxoN1JDo',
    'WECHAT_PAY_MCHID'      =>  '1448271002',
    'WECHAT_PAY_KEY' => '8bc14cae24d83b2007b71ede26c45a35',
    'WECHAT_PAY_IP'=>'139.199.13.64',

    'OUTER_SECRET'=>'721dcf1ca1509106efcceca3c3de1c7c',

    'ONWALL_USE_REDIS_DB'=>2,
    'ONWALL_RESEND_TIME'=>7200, //两小时内重发

    //'配置项'=>'配置值'
    'LAYOUT_ON'=>true,
    'LAYOUT_NAME'=>'layout',
    'COOKIE_TOKEN_SECRET'=>'xiangjiao2017%$#@!',
    'COOKIE_EXPIRE'=>3600*24*30,
    'LOGIN_VERIFYCODE'=>false,
    'LUOSIMAO_PASSWD'=>'a1151b0e09b998f1dda7ae0715a9f8f1',
    'AIPSPEECH_APPID'=>"9836685",
    'AIPSPEECH_APIKEY'=>"G5oxPtSc7HMIGIrzG8PRKvy3",
    'AIPSPEECH_SECRETKEY'=>"I3ff6b966dVn0ucdfRBDt1Tby92wMLz6",
    'SILK_HOST'=>'https://vrpcdn.balabalafun.cn',
    'PRICE_LIST'=>array(
        array('money'=> 1, 'end' =>'元', 'c_'=> ''),
        array('money'=> 5, 'end'=> '元', 'c_'=> ''),
        array('money'=> 20, 'end'=> '元', 'c_'=> ''),
        array('money'=> 50, 'end'=> '元', 'c_'=> ''),
        array('money'=> 100, 'end'=> '元', 'c_'=> 'last-child')
    )
);