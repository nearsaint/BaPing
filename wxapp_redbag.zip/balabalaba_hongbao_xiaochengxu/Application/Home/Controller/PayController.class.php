<?php
namespace Home\Controller;
use Home\Model\OrdersModel;
use Home\Model\RedpackModel;
use Home\Model\UsersModel;
use Think\Log;
class PayController extends \Think\Controller{
    function wxpay($order_id){
        Vendor('Wxpay.WxPay#Api');
        Vendor('Wxpay.WxPay#MicroApps');

        $orderdao=new OrdersModel();
        $orderinfo=$orderdao->where("id=".$order_id)->find();
        if($orderinfo['status']==1){
            $this->error('订单已经支付请不要重复提交支付');
        }
        $orderinfo = $orderdao->findByOrderidAndUpdateSN($order_id);
        $user=M('Users')->where("id=".$orderinfo['uid'])->find();
        $openId=$user['openid'];
        $input = new \WxPayUnifiedOrder();

        $input->SetBody("香蕉口令悬赏");
        $input->SetAttach(json_encode(array('order_id'=>$order_id,'order_sn'=>$orderinfo['order_sn'],'money'=>$orderinfo['money'])));
        $input->SetOut_trade_no($orderinfo['order_sn']);
        $input->SetTotal_fee(intval($orderinfo['money']*100));
        $input->SetTime_start(date("YmdHis"));
        $input->SetTime_expire(date("YmdHis", time() + 600));
        $input->SetGoods_tag("香蕉口令悬赏");
        $input->SetNotify_url(U('Home/Pay/wx_notify',array(),'',true));
        $input->SetTrade_type("JSAPI");
        $input->SetOpenid($openId);
        $result = \WxPayApi::unifiedOrder($input);
        $export=var_export($input,true);
        \Think\Log::write($export);
        $export=var_export($result,true);
        \Think\Log::write($export);
        if($result['return_code']=='FAIL'){
            $json = array('error' => 1, 'msg' => $result['return_msg'],'result'=>array('redpack_id'=>$orderinfo['redpack_id'],'uid'=>$orderinfo['uid']));
            $this->ajaxReturn($json);
            return;
        }else{
            $tools = new \MicroApps();
            $apps_param=json_decode($tools->GetParameters($result),true);

            $apps_param['redpack_id']=$orderinfo['redpack_id'];
            $apps_param['money']=$orderinfo['money'];
            $apps_param['uid']=$orderinfo['uid'];
            $apps_param['use_balance']=0;
            $export=var_export($apps_param,true);
            \Think\Log::write($export);
            unset($apps_param['appId']);
            $json = array('error' => 0, 'msg' => "success", 'result' => $apps_param);
            $this->ajaxReturn($json);
            return;
        }

    }
    //微信APP支付后台响应接口
    function wx_notify(){
        Vendor('Wxpay.WxPay#Api');
        Vendor('Wxpay.WxPay#WxPayNotifyCallBack');
        $raw_xml = file_get_contents("php://input");
        $notify = new \WxPayNotifyCallBack();

        $notify->Handle(false);
        $res = $notify->GetValues();

        if($res['return_code'] ==="SUCCESS" && $res['return_msg'] ==="OK"){
            libxml_disable_entity_loader(true);
            $ret = json_decode(json_encode(simplexml_load_string($raw_xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);
            $orderno=$ret['out_trade_no'];
            $money=$ret['total_fee'];
            $transaction_id=$ret['transaction_id'];
            $mch_id=$ret['mch_id'];
            $openid=$ret['openid'];
            $attch=$ret['attach'];
            $OrderDao=new OrdersModel();
            $order_info = $OrderDao->getOrderBySN($orderno);
            Log::write("订单:{$orderno} 金额:{$money} 交易号:{$transaction_id}");
            if ($order_info) {
                Log::write('订单状态：order_info.status=' . $order_info['status']);
                if ($order_info['status'] == 1) {
                    //如果已经支付，则不重复更新订单状态
                    Log::write("重复通知直接返回success");
                    echo 'status==1';
                    exit();
                } else {
                    //成功支付  但 我平台order.status=0时处理
                    if ($order_info['money'] == $money / 100) {

                        $status = $OrderDao->finishOrder($order_info['id'], $transaction_id,"", ($money / 100), 'native', $mch_id, $openid);
//                        $OrderDao->addIncome($order_info);
                        $incomelogdao=new \Home\Model\UsersIncomeLogModel();
                        $incomelogdao->incomeLog($order_info['uid'],$order_info['redpack_id'],($money / 100),2); //记录收入

                        if ($status) {
                            Log::write("接口回调收到通知参数，完成订单id=" . $order_info['id'] . " trans_id={$transaction_id},mch_id={$mch_id},money=" . ($money / 100));


                            if($order_info['balance']>0){
                                $userdao=new UsersModel();
                                $user=$userdao->findByuid($order_info['uid']);
                                if($user['blocked_balance']<$order_info['balance']){
                                    $userdao->where("id=".$order_info['uid'])->setField("blocked_balance",0);
                                }else{
                                    $userdao->where("id=".$order_info['uid'])->setDec("blocked_balance",$order_info['balance']);
                                }


                            }else{
                                M("Redpack")->where("id=".$order_info['redpack_id'])->setField('status',1);
                            }
                        } else {
                            Log::write("接口回调收到通知参数，完成订单时出错");
                            echo '接口回调收到通知参数，完成订单时出错';
                            exit();
                        }
                    } else {
                        Log::write("接口回调收到通知参数，金额不对应order.money=" . $order_info['money'] . " 通知金额money=" . ($money / 100));
                        echo "接口回调收到通知参数，金额不对应order.money=" . $order_info['money'] . " 通知金额money=" . ($money / 100);
                        exit();
                    }
                }
            } else {
                Log::write("接口回调收到通知参数，无法找到Order_SN＝{$orderno}对应的订单");
                echo "接口回调收到通知参数，无法找到Order_SN＝{$orderno}对应的订单";
                exit();
            }
//            \Think\Log::write('微信APP支付成功订单号'.$ret['out_trade_no'], \Think\Log::DEBUG);
            //在此处处理业务逻辑部分
        }
    }

}