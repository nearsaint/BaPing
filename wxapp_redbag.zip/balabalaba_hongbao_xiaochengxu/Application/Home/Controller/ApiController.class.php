<?php
namespace Home\Controller;

use Home\Model\OrdersModel;
use Home\Model\RedpackModel;
use Home\Model\UsersIncomeLogModel;
use Home\Model\UsersModel;
use Home\Model\VoiceFailModel;

class ApiController extends HomeController
{
    public function emoji_test()
    {
////       $reddao=new RedpackModel();
////        $reddao->addRedpackData(1);
//        Vendor("baiduvoice.LCS");
//        $lcs = new \LCS();
////返回最长公共子序列
//        echo $lcs->getLCS("你好","尼好");
////返回相似度
//        echo $lcs->getSimilar("你好","尼好");
//
//        $bytes=utf8_bytes(0x1F197);
//        $str = "Hello $bytes World";
//        var_dump(emoji2unicode($str));

        $dao=new UsersModel();

        var_dump($dao->findByuid(2));
//        $dao->clearHasTakeRedpackCache(2);
//        $result=$dao->splitReward_pre(10,3,rand(100,1000));
//        var_dump($result);
//        vendor("baiduvoice.pinyin");
//        $pinyin = new \pinyin();
//        var_dump($pinyin::utf8_toArray('谢写老板'));
//        var_dump($pinyin::utf8_toArray('谢谢老板'));

    }
    public function voice_test()
    {
        $voice_path = $_SERVER['DOCUMENT_ROOT'] . '/0.amr';
        Vendor("baiduvoice.AipSpeech");

        $appId = '9836685';

        $apiKey = 'G5oxPtSc7HMIGIrzG8PRKvy3';

        $secretKey = 'I3ff6b966dVn0ucdfRBDt1Tby92wMLz6';
        $AipSpeech = new \AipSpeech($appId, $apiKey, $secretKey);
        $result = $AipSpeech->asr(file_get_contents($voice_path), 'amr', 8000, array(
            'lan' => 'zh',
        ));
        var_dump($result);
    }

    public function index_list($uid = 0)
    {
        $data['money_items'] = C("PRICE_LIST");

        $txt_list = M("voice_txt")->order("rand() desc")->field('txt as `text`')->limit(3)->select();
        $count = count($txt_list);
        foreach ($txt_list as $key => &$val) {
            if ($count == ($key + 1)) {
                $val['c_'] = "last-child";
            } else {
                $val['c_'] = "";
            }
        }
        $data['key_items'] = $txt_list;
        if ($uid > 0) {
            $userdao = new UsersModel();
            $user = $userdao->findByuid($uid);
            $data['user'] = $user;
        }

        if ($data) {
            $this->echo_json(0, 'success', $data);
        } else {
            $this->echo_json(1, 'fail');
        }
    }

    public function all_history($uid)
    {
//       $user_id = 1;
        $user_id = $uid;
        if ($user_id && $user_id > 0) {
            $user = $this->get_user($user_id);
            if ($user) {
                $data['user'] = $user;

                $get_list = $this->get_history($user);
                $get_num = 0;
                $get_total = 0;
                if ($get_list) {
                    foreach ($get_list as &$one) {
                        $get_num += 1;
                        $get_total += doubleval($one['money']);
                    }
                }

                $send_list = $this->send_history($user);
                $send_num = 0;
                $send_total = 0;
                if ($send_list) {
                    foreach ($send_list as &$one) {
                        $send_num += 1;
                        $send_total += doubleval($one['money']);
                    }
                }


                $data['get_history'] = $get_list;
                $data['get_num'] = $get_num;
                $data['get_total'] = $this->explain_money($get_total);
                $data['send_history'] = $send_list;
                $data['send_num'] = $send_num;
                $data['send_total'] = $this->explain_money($send_total);
                if ($data) {
                    $this->echo_json(0, 'success', $data);
                } else {
                    $this->echo_json(1, 'fail');
                }
            } else {
                $this->echo_json(9, 'no user');
            }
        } else {
            $this->echo_json(10, 'no user id');
        }
    }
    public function cashout($uid,$money=0){
        try {
            $userdao = new UsersModel();
            $user = $userdao->findByuid($uid);
            if (!$user) {
                $this->echo_json(1, "用户不存在");
            }
            if (doubleval($money) < 1) {
                $this->echo_json(1, "金额不能小于1，请重新输入提现金额");
            }
            $current_balance = $user['balance'];
            if ($current_balance < $money) {
                $this->echo_json(1, "余额不足，请重新输入");
            }
            $today = strtotime(date("Y-m-d"),time());
            $end = $today+3600*24;
            $incomedao = new UsersIncomeLogModel();
            $todayCount=$incomedao->where("uid=$uid and income_type=1 and add_time > $today and add_time<{$end}")->count();
            if($todayCount>=3){
                $this->echo_json(1, "当天提现次数超过3次，请明天再提现。");
            }
            $ip = C("WECHAT_PAY_IP");
            $trade_no = date('YmdHis', time()) . rand(100, 999);
            \Think\Log::write($trade_no);
            $Compay = new \Org\Wx\ComPay();
            $Compay->setMchid(C("WECHAT_PAY_MCHID"));
            $Compay->setMchAppid(C("WECHAT_APPID"));
            $Compay->setApiKey(C("WECHAT_PAY_KEY"));
            $Compay->setPartnerTradeNo($trade_no);//订单号;
            $Compay->setReOpenid($user['openid']);//接收红包的openid;
            $Compay->setAmount(intval($money * 100));
            $Compay->setSpbillCreateIp($ip);
            $Compay->setSendName("香蕉互娱快来说");
            $Compay->setWishing("香蕉互娱感谢你的支持");
            $Compay->setActName("快来说提现");
            $Compay->setRemark("快来说提现");
            $Compay->setCheckName('NO_CHECK');
            $Compay->setApiclient("/home/wwwroot/wx_pay_cert_old/apiclient_cert.pem", "/home/wwwroot/wx_pay_cert_old/apiclient_key.pem");
//            $result = $Compay->ComPay();
//            \Think\Log::write($money * 100);
//            \Think\Log::write(json_encode($result));
            $result=false;
            if ($result == false) {
                $this->echo_json(2, $Compay->error());
            } else {
                $incomedao->incomeLog($uid, 0, $money, 1,$trade_no);
                $userdao->where("id=" . intval($uid))->setDec("balance", $money);
                $return=array();
                $return['money']=$money;
                $return['time']=$this->explain_time(time());
                $return['title']="快来说";
                $user=$userdao->findByuid(intval($uid));
                $this->echo_json(0, '申请提现成功，将在3个工作日内处理完成！',array('balance'=>$user['balance']));
            }
        }catch (\Think\Exception $e){
            \Think\Log::write($e->getTraceAsString());
            $this->echo_json(99, $e->getMessage());
        }
    }

//    public function user_cashout($money=10.0){
//        try {
//            if ($money < 10) {
//                $this->echo_json(1, "金额不能小于10，请重新输入提现金额");
//            }
//
//            $ip = C("WECHAT_PAY_IP");
//            $openid = $this->user['wx_openid'];
//            $userdao=new \Merchant\Model\UsersModel();
//            $user=$userdao->where("id=".$this->user['id'])->find();
//            $current_balance=$user['balance'];
//            if($current_balance<$money){
//                $this->echo_json(1, "余额不足，请重新输入");
//            }
//
//            $trade_no =date('YmdHis', time()).rand(100,999);
//            \Think\Log::write($trade_no);
//            $Compay = new \Org\Wx\ComPay();
//            $Compay->setMchid(C("WECHAT_PAY_MCHID"));
//            $Compay->setMchAppid(C("WECHAT_APPID"));
//            $Compay->setApiKey(C("WECHAT_PAY_KEY"));
//            $Compay->setPartnerTradeNo($trade_no);//订单号;
//            $Compay->setReOpenid($openid);//接收红包的openid;
//            $Compay->setAmount($money * 100);
//            $Compay->setSpbillCreateIp($ip);
//            $Compay->setSendName("香蕉互娱");
//            $Compay->setWishing("香蕉互娱感谢你的支持");
//            $Compay->setActName("提现红包");
//            $Compay->setRemark("提现红包");
//            $Compay->setApiclient("/home/wwwroot/wxpay_cert/apiclient_cert.pem", "/home/wwwroot/wxpay_cert/apiclient_key.pem");
//            $result=$Compay->RedBag();
//            if ($result == false) {
//                $this->echo_json(2, $Compay->error());
//            } else {
//                $income_dao=new \Home\Model\UsersIncomeLogModel();
//                $income_dao->incomeLog($this->user['id'],null,null,$money,1);
//                $userdao->where("id=".$this->user['id'])->setDec("balance",$money);
//                $cashout = array();
//                $cashout['trade_type'] = 'redbag';
//                $cashout['trade_no'] = $trade_no;
//                $cashout['current_balance']=$current_balance-$money;
//                $cashout['add_time']=time();
//                $cashout['prev_balance']=$current_balance;
//                $cashout['money']=$money;
//                $cashout['user_id']=$this->user['id'];
//                $cashout['income_type']=1;
//                $cashout['status']=1;
//                $ubldao=new \Merchant\Model\UsersBalanceLogModel();
//                $ubldao->data($cashout)->add();
//                $this->echo_json(0, '提现成功');
//            }
//        } catch (\Think\Exception $e) {
//            \Think\Log::write($e->getTraceAsString());
//            $this->echo_json(1, $e->getMessage());
//        }
//    }
    private function get_user($uid)
    {
        if ($uid == 0 || $uid == null || strlen($uid) == 0) {
            return false;
        }
        $user = M("users")->field('id,nickname,gender as sex,avatarUrl as avatar')->cache(true, 3600)->where("id=" . $uid)->find();
        $user['nickname'] = unicode2emoji($user['nickname']);
//        $user = array(
//            'id'=>$uid,
//            'nickname'=>'test_user',
//            'sex'=>1,
//            'avatar'=>'https://wx.qlogo.cn/mmopen/vi_32/0ZSHicG8Ky9WLpfqZTiaYN4wgwOVngSNGwqnLbeTian4uNF9QjKhgtu4ZNLLt42H0XXxKZhCqOCEA0Z4QyP66gVpQ/0',
//        );
        if ($user) {
            return $user;
        } else {
            return array();
        }
    }

    /**
     * 自己发送了红包的记录
     * @param $user
     * @return array
     */
    private function send_history($user)
    {

        $dao = new RedpackModel();
        $data = $dao->getMyRedpack($user['id']);
        if ($data) {
            foreach ($data as &$one) {
                $hasTake = $dao->getHasTakeNum($one['id']);
                $one['text'] = $one['txt'];
                $one['quantity'] = $hasTake . '/' . $one['num'];
                $one['money'] = $this->explain_money($one['money']);
                $one['time'] = $this->explain_time($one['add_time']);
            }
            return $data;
        } else {
            return array();
        }
    }

    public function cancelRedpack($uid,$redpack_id){
        \Think\Log::write("=======cancelRedpack=========");
        \Think\Log::write($redpack_id);
        if($redpack_id>0&&$redpack_id) {
            //返还冻结余额
            $userdao=new UsersModel();
            $dao=new RedpackModel();
            $redpack=$dao->detail($redpack_id);
            if($redpack) {
                $order_id = $redpack['order_id'];
                $userdao->unblock_balance($uid, $order_id);
                $this->echo_json(0, 'cancel success');
            }else{
                $this->echo_json(1, 'fail redpack not found');
            }

        }else{
            $this->echo_json(1, 'fail redpack_id is null');
        }
    }
    /**
     * @param string $txt
     * @param int $uid
     * @param int $money
     * @param int $num
     * 添加新红包，并且返回支付数据包，让前端进行支付操作
     */
    public function new_redpack($txt="",$uid=0,$money=0,$num=0){
        if(doubleval($money)/doubleval($num)<1){
            $this->echo_json(1,'每人悬赏金额不能低于1元');
        }
        if (!preg_match('/^[\x{4e00}-\x{9fa5}]+$/u',$txt)) {
            $this->echo_json(1,'口令必须全部中文字，请输入中文字符！');
        }
        if($txt==null||strlen($txt)<=0){
            $this->echo_json(1,'口令太短，请输入2个中文字以上');
        }
        if($uid<=0){
            $this->echo_json(1,'用户参数完整');
        }
        //$this->echo_json(0,'success');
//        $money=$num*0.01;
        $orderdao=new OrdersModel();
        $order_money=$money*1.1;
        $userdao=new UsersModel();
        $reddao = new RedpackModel();
        $user=$userdao->findByuid($uid);
        $blocked_money=$userdao->block_balance($uid,$order_money);//冻结余额
        if($blocked_money===false){
            $this->echo_json(1,'add redpack fail');
        }
        if($blocked_money==$order_money){
            //余额大于下单金额扣除冻结金额后，直接添加红包
            $redpack = $reddao->addRedpack($txt, $money, $num, $uid, -1,1);
            $incomedao=new UsersIncomeLogModel();
            $incomedao->addIncomeLog($uid,$redpack['id'],$blocked_money,$user['balance'],($user['balance']-$blocked_money),2,'');
            M("Users")->where('id='.$user['id'])->setDec("blocked_balance",$blocked_money);
            $this->echo_json(0,'success',array('use_balance'=>1,'redpack_id'=>$redpack['id'],'money'=>$redpack['money'],'uid'=>$uid));
        }else {
            $orderinfo = $orderdao->makeOrder($order_money,$blocked_money, $uid, 0);
            $order_id=$orderinfo['id'];
            $redpack = $reddao->addRedpack($txt, $money, $num, $uid, $order_id);
            $orderdao->where("id=" . $orderinfo['id'])->setField('redpack_id', $redpack['id']);
            if(!$redpack){
                $this->echo_json(1,'add redpack fail');
            }else{
                $pay=A("Pay");
                $result = $pay->wxpay($orderinfo['id']);
                if($result){
                    $this->echo_json(0,'success',$result);
                }else{
                    $this->echo_json(1,'wxpay fail');
                }
            }
        }

    }

    /**
     * 抢红包
     */
    public function take_redpack()
    {
        try {
            $uid = I("post.uid");
            $redpack_id = I("post.redpack_id");


            $dao = new RedpackModel();
            $redpack = $dao->detail($redpack_id);
            if($redpack['expire_time']==0){
                if($redpack['add_time']+(48*3600)<time()){
                    $this->echo_json(2, '悬赏已过期', $this->p_getRedpackAll($redpack_id, $uid));
                }
            }else{
                if($redpack['expire_time']<time()){
                    $this->echo_json(2, '悬赏已过期', $this->p_getRedpackAll($redpack_id, $uid));
                }
            }
            if (!$uid) {
                $this->echo_json(99, 'uid not found');
            }
            if (!$redpack) {
                $this->echo_json(99, 'redpack not found');
            }
            if ($redpack['status'] == 0) {
                $this->echo_json(99, 'redpack not found');
            }
            if ($redpack['status'] == 2) {
                $this->echo_json(2, '你已抢过了', $this->p_getRedpackAll($redpack_id, $uid));
//            $this->redpack_detail($redpack_id, $uid,2);
            } else {
                $cantake = $dao->canTake($redpack_id, $uid);
                if ($cantake == 1) {
                    $this->echo_json(2, '你已抢过了', $this->p_getRedpackAll($redpack_id, $uid));
                    //$this->redpack_detail($redpack_id, $uid,2);
                }
//            $dao->getDataList($redpack_id);


                $upload = new \Think\Upload();// 实例化上传类
                $upload->maxSize = 1024 * 1024;// 设置附件上传大小 限制1M大小
                $upload->exts = array('silk');// 设置附件上传类型
                $upload->rootPath = './Public/Uploads/';
                $upload->savePath = '';
                $upload->saveName = array('uniqid', '');
                $upload->autoSub = true;
                $upload->subName = array('date', 'Ymd');
                $info = $upload->uploadOne($_FILES['file']);
                if (!$info) {
                    // 上传错误提示错误信息
                    $this->echo_json(99, 'upload file fail');
                } else {// 上传成功 获取上传文件信息
                    $src_path = $_SERVER['DOCUMENT_ROOT'] . '/Public/Uploads/' . $info['savepath'] . $info['savename'];
                    $url_src_path = C("SILK_HOST").'/Public/Uploads/' . $info['savepath'] . $info['savename'];
                    if (file_exists($src_path) && filesize($src_path) > 0) {
                        transSilk2Pcm($src_path);
                    } else {
                        unlink($src_path);
                        $this->echo_json(99, 'fail transSilk2Pcm');
                    }
                    $pcm_dest_path = $_SERVER['DOCUMENT_ROOT'] . '/Public/Uploads/' . $info['savepath'] . str_replace('silk', 'pcm', $info['savename']);
                    if (file_exists($pcm_dest_path) && filesize($pcm_dest_path) > 0) {
                        transPcm2Amr($pcm_dest_path);
                    } else {
                        unlink($pcm_dest_path);
                        $this->echo_json(99, "fail transPcm2Amr");
                    }
                    $amr_dest_path = $_SERVER['DOCUMENT_ROOT'] . '/Public/Uploads/' . $info['savepath'] . str_replace('silk', 'amr', $info['savename']);
                    unlink($pcm_dest_path);
                    if (file_exists($amr_dest_path) && filesize($amr_dest_path) > 0) {
                        //添加进数据库并且抢红包
                        Vendor("baiduvoice.AipSpeech");
                        Vendor("baiduvoice.LCS");
                        /**
                         *  'AIPSPEECH_APPID'=>"9836685",
                         * 'AIPSPEECH_APIKEY'=>"G5oxPtSc7HMIGIrzG8PRKvy3",
                         * 'AIPSPEECH_SECRETKEY'=>"I3ff6b966dVn0ucdfRBDt1Tby92wMLz6",
                         */
                        $AipSpeech = new \AipSpeech(C("AIPSPEECH_APPID"), C("AIPSPEECH_APIKEY"), C("AIPSPEECH_SECRETKEY"));
                        $result = $AipSpeech->asr(file_get_contents($amr_dest_path), 'amr', 8000, array(
                            'lan' => 'zh',
                        ));
                        unlink($amr_dest_path);
//                    var_dump($amr_dest_path);
//                    var_dump($result);
//                    $txt=implode($result['result']);
                        $txt_match = 0;
                        $txt = "";
                        $txtpinyin = "";
                        $similar = 0;
                        vendor("baiduvoice.pinyin");
                        $pinyin = new \pinyin();
                        foreach ($result['result'] as $txt) {
                            $txt = str_replace("，", "", $txt);
                            $txt = str_replace("。", "", $txt);
                            \Think\Log::write($txt);
                            $lcs = new \LCS();
                            //返回最长公共子序列
                            $txtpinyin=$pinyin->utf8_to($txt);
                            $similar = $lcs->getSimilar($pinyin->utf8_to($redpack['txt']),$txtpinyin);
                            $similar1 = $lcs->getSimilar($redpack['txt'],$txt);
                            $similar=$similar*0.70+$similar1*0.2 ;
                            if(strlen($redpack['txt'])==strlen($txt)){
                                $similar=$similar+0.1;
                            }
                            if ($similar> 0.8) {
                                $txt_match = 1;
                            }
                        }
                        $voice_form = voiceform($amr_dest_path);
                        $voice_bit_rate = $voice_form['format']['bit_rate'];
                        $voice_file_size = $voice_form['format']['size'];
                        $voice_duration = $voice_form['format']['duration'];
                        $voice_filename = $amr_dest_path;
                        $voice_source_filename = $src_path;
                        $voice_url = $url_src_path;
                        if ($txt_match == 1) {


                            $dao = new RedpackModel();
                            $redpack = $dao->detail($redpack_id);
                            if ($redpack['status'] == 0 || $redpack['status'] == 2) {
                                $this->echo_json(2, '抢悬赏失败', $this->p_getRedpackAll($redpack_id, $uid));
//                            $this->redpack_detail($redpack_id,$uid,2);

                            } else {
                                if ($dao->canTake($redpack_id, $uid) == 1) {
                                    $this->echo_json(2, '你已抢过了', $this->p_getRedpackAll($redpack_id, $uid));
//                                $this->redpack_detail($redpack_id,$uid,2);

                                } else {
                                    //进行抢红包流程
                                    $reddata = $dao->takeRedpack($redpack_id, $uid);
                                    if ($reddata) {

                                        $dao->updateVoiceData($reddata['id'], $voice_bit_rate, $voice_file_size, $voice_duration, $voice_filename, $voice_source_filename, $voice_url,$txt);
                                        $canTake = $dao->canRedpocketData($redpack_id, $uid);
                                        if (false == $canTake) {
                                            $dao->finishRedpack($redpack_id);
                                        }
                                        $dao->clearHasTakeRedpackCache($uid);
                                        $return_arr=$this->p_getRedpackAll($redpack_id, $uid);
                                        $return_arr['txt']=$result['result'];
                                        $return_arr['txtpinyin']=$txtpinyin;
                                        $return_arr['similar']=$similar;
                                        $this->echo_json(0, '抢悬赏成功', $return_arr);
//                                    $this->redpack_detail($redpack_id, $uid,0); //抢成功
                                    } else {
                                        $this->echo_json(2, '抢悬赏失败', $this->p_getRedpackAll($redpack_id, $uid));
                                        //$this->redpack_detail($redpack_id, $uid,2); //抢失败
                                    }
                                }

                            }
                        } else {
                            $return_arr=$this->p_getRedpackAll($redpack_id, $uid);
                            $return_arr['txt']=$result['result'];
                            $return_arr['similar']=$similar;
                            $data=array();
                            $data['add_time']=time();
                            $data['voice_url']=$voice_url;
                            $data['voice_source_filename']=$voice_source_filename;
                            $data['voice_filename']=$voice_filename;
                            $data['voice_duration']=$voice_duration;
                            $data['voice_file_size']=$voice_file_size;
                            $data['voice_bit_rate']=$voice_bit_rate;
                            $data['voice_txt']=$txt;
                            $data['redpack_id']=$redpack_id;
                            $data['uid']=$uid;
                            $vfdao=new VoiceFailModel();
                            $vfdao->addAndUpdateVoice($data);
                            $this->echo_json(1, '悬赏口令不匹配', $return_arr);
//                        $this->redpack_detail($redpack_id, $uid,1);

                        }
                        if ($result['err_no'] > 0) {
                            $this->echo_json(99, $result['err_msg']);
                        }
                    } else {
                        unlink($amr_dest_path);
                        $this->echo_json(99, "fail amr not found");
                    }
                    //$this->echo_json(0, 'success', array("file_url" => 'http://' . $_SERVER['HTTP_HOST'] . '/Public/Uploads/' . $info['savepath'] . $info['savename']));
                }
            }
        }catch(\Think\Exception $e){
            \Think\Log::write($e->getTraceAsString());
            $this->echo_json(99, "网络错误");
        }
    }

    private function p_getRedpackAll($redpack_id,$uid){
        $redpackdao = new RedpackModel();
        $redpack = $redpackdao->detail($redpack_id);
        if($redpack==false){
            return false;
        }
        $userdao=new UsersModel();
        $user=$userdao->findByuid($redpack['uid']);
        /**
         * has_take 1可抢，2抢光，3抢过 , 4抢过并且抢光 5已过期
         */
        $takethis = $redpackdao->hasTakeThisRedpackData($redpack_id,$uid);

        $take_money=0;
        if($redpack['status']==2){

            if($takethis){
                $take_money=$takethis['money'];
                $hasTake=4;
            }else{
                $hasTake=2;
            }

        }else{
            if($redpack['status']==3){
                $hasTake = 5;
            }else {
                if ($takethis == false) {
                    $hasTake = 1;
                } else {
                    $take_money = $takethis['money'];
                    $hasTake = 3;
                }
            }
        }
        \Think\Log::write($redpack['add_time']+(48*3600));
        \Think\Log::write(time());
        if($redpack['expire_time']==0){
            if(($redpack['add_time']+(48*3600))<time()){
                \Think\Log::write("expire redpack");
                $hasTake=5;
            }
        }else{
            if($redpack['expire_time']<time()){
                $hasTake=5;
            }
        }
        \Think\Log::write($hasTake);
        $msg="";
        switch($hasTake){
            case 1: $msg = '长按并用普通话说出以上口令可获取悬赏'; break; //可抢
            case 2: $msg = '别看了,渣都没有了!'; break;  //抢光
            case 3: $msg = '已存入账户余额'; break; //抢过
            case 4: $msg = '已存入账户余额'; break; //抢过并抢光
            case 5: $msg = '口令已过期'; break; //已过期
            default: $msg = ''; break;
        }
        $list = $redpackdao->getDataList($redpack_id,"status=1 and uid>0");
        foreach($list as &$one){

            $one['take_time']=$this->explain_time($one['take_time']);
            $one['voice_duration']=ceil($one['voice_duration']);
        }
        $redpack['quantity']=count($list).'/'.$redpack['num'];
        $redpack['user']=$user;
        return  array('take_money'=>$take_money,"redpack" => $redpack, 'msg' => $msg, 'list' => $list, 'has_take' => $hasTake);
    }
    /**
     * @param $redpack_id
     * @param $uid
     * 红包详细内容
     */
    public function redpack_detail($redpack_id=0, $uid=0)
    {
        if($redpack_id==0||$uid==0){
            $this->echo_json(1, "fail param is redpack_id={$redpack_id} uid={$uid}");
        }

        $result=$this->p_getRedpackAll($redpack_id,$uid);
        if ($result) {

            $this->echo_json(0, 'success', $result);
        } else {
            $this->echo_json(1, 'fail not found redpack');
        }
    }

    /**
     * 自己抢了多少红包记录
     * @param $user
     * @return array
     */
    private function get_history($user)
    {

        $dao = new RedpackModel();
        $userdao = new UsersModel();
        $data = $dao->getHasTakeRedpack($user['id']);
        if ($data) {
            foreach ($data as &$one) {

                $send_user = $userdao->findByuid($one['uid']);
                $one['avatar'] = $send_user['avatarUrl'];
                $one['nickname'] = $send_user['nickname'];
                $one['sex'] = $send_user['gender'];
                $one['text'] = $one['txt'];
                $one['money'] = $this->explain_money($one['take_money']);
                $one['time'] = $this->explain_time($one['take_time']);
            }
            return $data;
        } else {
            return array();
        }
    }

    public function faq()
    {
        $data=M("faq")->cache(true,14400)->select();
        $this->echo_json(0, 'success', $data);
    }
    public function get_fail_voice($redpack_id,$page=0,$uid=0){
        $dao=new VoiceFailModel();
        $list=$dao->where("redpack_id={$redpack_id}")->page($page,20)->cache(true,120)->select();
        foreach($list as &$one){
            $one['nickname']=base64_decode($one['nickname']);
        }
        $this->echo_json(0,"ok",$list);
    }
}