<?php
namespace Home\Controller;
use Home\Model\RedpackModel;
use Home\Model\UsersIncomeLogModel;
use Home\Model\UsersModel;
use Think\Controller;
class HomeController extends Controller {

    //基础配置
    public $page_size = 10;  //数据条数为10

    //初始化
    public function _initialize(){

    }


    //json输出
    public function echo_json($err, $msg, $result = ''){
        $json = array('error' => $err, 'msg' => $msg, 'result' => $result);
        echo json_encode($json,JSON_UNESCAPED_UNICODE);
        exit();
    }
    public function processExpire(){
        $list = M("Redpack")->where("status=1 and expire_time<unix_timestamp()")->limit(1000)->select();
        $dao=new RedpackModel();
        $udao=new UsersModel();
        $uldao=new UsersIncomeLogModel();
        $returnMsg=0;

        foreach($list as $one){
            $redpack=$one;
            $datalist=$dao->getDataList($redpack['id'],'uid=0');
            $count=count($datalist);
            if($count<=$redpack['num']){
                //处理未抢红包的数量

                $countMoney=0;
                foreach($datalist as $data){
                    if(intval($data['uid'])==0){
                        $countMoney=doubleval($countMoney)+doubleval($data['money']);
                    }
                }

                $refund_money=round($countMoney*1.05,2);
                if($refund_money<$redpack['money']*1.1) {

                    $dao->where("id=" . $redpack['id'])->setField("status", 3);
                    $uldao->incomeLog($redpack['uid'], $redpack['id'], $refund_money, 3);
                    $udao->addIncome($redpack['uid'], $refund_money);
                    $returnMsg+=1;
                }else{
                    $dao->where("id=" . $redpack['id'])->setField("status", 3);
                }

            }else{
                $dao->where("id=".$redpack['id'])->setField("status",3);
            }
        }
        echo "process:".$returnMsg;
    }

    public function explain_time($time){
        if ($time && $time > 0) {
            return date('Y-m-d H:i:s', $time);
        }else{
            return '';
        }
    }

    public function explain_money($money){
        return sprintf("%.2f", $money);
    }
}
