<?php
namespace Home\Controller;

use Home\Model\UsersModel;

class LoginController extends HomeController {


    private $share=array('我发起了口令悬赏，说对有赏金');

    public function login()
    {

        $userdao = new UsersModel();
        $code = I("post.code");
        $uid=I("post.uid",0);

        if ($code||intval($uid)>0) {
            if(intval($uid)>0){
                $user = $userdao->findByuid($uid);
                if($user) {
                    if (($user['last_time'] + 24 * 3600) < time()) {
                        $this->echo_json(0, 'success', array('user' => $user, 'share' => $this->share));
                    }
                }
            }
            //https://api.weixin.qq.com/sns/jscode2session?appid=APPID&secret=SECRET&js_code=JSCODE&grant_type=authorization_code
            $arr = array(
                'appid' => C("WECHAT_APPID"),
                'secret' => C("WECHAT_APPSECRET"),
                'js_code' => $code,
                'grant_type' => 'authorization_code'
            );
            $retry=0;
            do{
                $code_session = $this->post_url('https://api.weixin.qq.com/sns/jscode2session', $arr);
                \Think\Log::write($code_session);
                $code_session = json_decode($code_session, true);
                $retry++;
                if($code_session['errcode']==40163){
                    $this->echo_json(999, 'code been used');
                }
                if($retry>2){
                    $this->echo_json(1, 'login fail');
                }
            } while (isset($code_session['errcode']));

            if ($code_session['openid'] && $code_session['session_key']) {
//                $user = $userdao->findByOpenid($code_session['openid']);
//                if ($user&&false) {
//                    //找到旧用户 ，直接显示登录，不进行解密消息体；
//                    $userdao->setLoginUser($user);
//                    $this->echo_json(0, 'success', array('user'=>$user,'share'=>$this->share));
//                }

                session(WX_SESSION_KEY, $code_session['session_key']);
                session(WX_OPENID, $code_session['openid']);
                $rawData = I("post.rawData", "", false);
                $signature = I("post.signature", "", false);
                $encryptedData = I("post.encryptedData", "", false);
                $iv = I("post.iv", "", false);
                $session_key = $code_session['session_key'];

                //TODO 验证签名

                if (sha1($rawData . $session_key) == $signature) {
                    vendor("wxaes.WXBizDataCrypt");
                    $wxBizDataCrypt = new \WXBizDataCrypt(C("WECHAT_APPID"), $session_key);
                    $data = array();
                    $errCode = $wxBizDataCrypt->decryptData($encryptedData, $iv, $data);
                    \Think\Log::write("================decryptData==================");
                    \Think\Log::write($data);
                    if ($errCode == 0) {
                        $json_data = json_decode($data, true);

                        $openid = $json_data['openId'];
                        $user = $userdao->findByOpenid($openid);
                        if (!$user) {
                            $user_data = array();
                            $user_data['openid'] = $openid;
                            $user_data['unionid'] = $json_data['unionId'];
                            $user_data['gender'] = $json_data['gender'];
                            $user_data['city'] = $json_data['city'];
                            $user_data['add_time'] = time();
                            $user_data['province'] = $json_data['province'];
                            $user_data['country'] = $json_data['country'];
                            $user_data['avatarUrl'] =  str_replace('/0','/132',$json_data['avatarUrl'] );
                            $user_data['last_time'] =time();
                            $user_data['nickname'] = emoji2unicode($json_data['nickName']);
                            $uid = $userdao->data($user_data)->add();
                            $user = $userdao->findByuid($uid);
                        }else{
                            if(!$user['unionid']||strlen($user['unionid'])==0){
                                $userdao->where('id='.$user['id'])->setField("unionid",$json_data['unionId']);
                            }
                            if(($user['last_time']+24*3600)>time()){
                                $userdao->where('id='.$user['id'])->setField("last_time",time());
                                $userdao->where('id='.$user['id'])->setField("avatarUrl", str_replace('/0','/132',$json_data['avatarUrl']));
                            }
                        }

                        $userdao->setLoginUser($user);
                        $this->echo_json(0, 'success', array('user'=>$user,'share'=>$this->share));
                    } else {
                        $this->echo_json(20, 'fail', $errCode);
                    }

                } else {
                    $this->echo_json(21, 'fail', "sign is wrong");
                }

            }  else {

                $this->echo_json(1, 'fail');

            }
        } else {
            $this->echo_json(2, 'no code');
        }
    }


    public function post_url($url,$data){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT,15);   //只需要设置一个秒的数量就可以
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        // post数据
        curl_setopt($ch, CURLOPT_POST, 1);
        // post的变量
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        $output = curl_exec($ch);
        curl_close($ch);
        //打印获得的数据
        //print_r($output);
        return $output;
    }
}