<?php
namespace Home\Model;
use \Think\Model;
class RedpackModel extends Model
{
    public function detail($id){
        if($id) {
            $result = $this->where("id={$id}")->find();
            return $result;
        }else{

            return false;
        }
        return $result;
    }
    public function addRedpack($txt,$money,$num,$uid,$order_id=0,$status=0){
        $data=array();
        $data['txt']=$txt;
        $data['money']=$money;
        $data['num']=$num;
        $data['uid']=$uid;
        $data['add_time']=time();
        $data['expire_time']=(time()+48*3600);
        $data['status']=$status;
        $data['order_id']=$order_id;

        $redpack_id=$this->data($data)->add();
        $data['id']=$redpack_id;
        if($redpack_id>0) {

            if($this->addRedpackData($redpack_id,$data)) {
                return $data;
            }else{
                return false;
            }
        }else{
            return false;
        }
    }
    public function getDataList($redpack_id,$wheremap=""){
        if(is_string($wheremap)){
            $wheremap=$wheremap . " and redpack_id={$redpack_id}";
        }else if(is_array($wheremap)){
            $wheremap['redpack_id']=$redpack_id;
        }
        $return = M("RedpackData")->where($wheremap)->select();
        foreach($return as &$one){
            if(is_base64($one['nickname'])==true){
                $one['nickname']=base64_decode($one['nickname']);
            }
        }
        return $return;
    }
    public function hasTakeThisRedpackData($redpack_id,$uid){
        if($uid) {
            $count = M('RedpackData')->where("uid={$uid} and redpack_id={$redpack_id}")->find();
            if(is_base64($count['nickname'])==true){
                $count['nickname']=base64_decode($count['nickname']);
            }

            return $count;
        }else{
            return false;
        }
    }

    public function canRedpocketData($redpack_id){
        $data=M("RedpackData")->where("uid=0 and redpack_id={$redpack_id}")->count();
        if($data>0){
            return $data;
        }
        return false;
    }
    public function getMyRedpack($uid){
        if($uid) {
            $list = $this->where("uid={$uid} and status>0")->order('id desc')->select();
            return $list;
        }else{
            return false;
        }
    }
    public function canTake($redpack_id,$uid){
//        $this->where("id={$redpack_id} and ")
        return M('RedpackData')->where("uid={$uid} and redpack_id={$redpack_id}")->count();
    }
    public function clearHasTakeRedpackCache($uid){
        $key="getHasTakeRedpack_".$uid;
        S($key,null);
    }
    public function getHasTakeRedpack($uid){
        $key="getHasTakeRedpack_".$uid;
        $data=S($key);
        if($data===false){
            $wheremap=M('RedpackData')->getTableName().".uid={$uid} and ".$this->getTableName().'.status>=1 ';
            $list=$this->field($this->getTableName().".*,".M('RedpackData')->getTableName().'.money as take_money,take_time')->join(M('RedpackData')->getTableName().' ON '.$this->getTableName().'.id='.M('RedpackData')->getTableName().".redpack_id")
                ->where($wheremap)->order(M('RedpackData')->getTableName().'.take_time desc')->select();
//            var_dump(M()->getLastSql());
            S($key,$list,240);
            return $list;
        }else{
            return $data;
        }
    }
    public function getHasTakeNum($redpack_id){
        return M('RedpackData')->where("uid>0 and redpack_id={$redpack_id}")->count();
    }
    public function updateVoiceData($data_id,$voice_bit_rate='8000',$voice_file_size='',$voice_duration='3.0',$voice_filename='',$voice_source_filename='',$voice_url="",$voice_txt=""){
        $data=array('voice_txt'=>$voice_txt,'voice_bit_rate'=>$voice_bit_rate,'voice_file_size'=>$voice_file_size,'voice_duration'=>$voice_duration,'voice_filename'=>$voice_filename,'voice_source_filename'=>$voice_source_filename,"voice_url"=>$voice_url);
        return M("RedpackData")->data($data)->where("id={$data_id}")->save();
    }
    public function takeRedpack($redpack_id,$user_id){
        try {
            $table_RedpackData = M("RedpackData")->getTableName();
            $this->execute("begin");
            $take_time = time();
            $data = $this->query("select * from {$table_RedpackData} where uid=0 and redpack_id={$redpack_id} limit 1 for update");
            if ($data == false) {
                $this->execute("commit");
                return false;
            }
            $data_id = $data[0]['id'];
            $usersdao=new \Home\Model\UsersModel();
            $userinfo=$usersdao->findByuid($user_id);
//            $this->execute("SET NAMES 'utf8mb4'");
            $userinfo['nickname']=base64_encode($userinfo['nickname']);

//            var_dump("update {$table_RedpackData} set uid={$user_id} ,nickname='{$userinfo['nickname']}' , avatarUrl='{$userinfo['avatarUrl']}' , gender={$userinfo['gender']} , status=1,take_time={$take_time} where id={$data_id} limit 1");die;
            $result = $this->execute("update {$table_RedpackData} set uid={$user_id} ,nickname='{$userinfo['nickname']}' , avatarUrl='{$userinfo['avatarUrl']}' , gender={$userinfo['gender']} , status=1,take_time={$take_time} where id={$data_id} limit 1");
            $this->execute("commit");
            if ($result == 1) {
                $finish_data = M($table_RedpackData)->where("id={$data_id}")->cache(false,3600)->find();
                //验证$finish_data
                if ($finish_data['uid'] == $user_id) {
                    if(doubleval($finish_data['money'])>0 && doubleval($finish_data['money'])<10000) {

                        $usersdao->addIncome($user_id, $finish_data['money']);
                        $incomelogdao=new \Home\Model\UsersIncomeLogModel();
                        $incomelogdao->incomeLog($user_id,$redpack_id,$finish_data['money'],0); //记录收入
                    }
                    return $finish_data;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        }catch(\Think\Exception $e){
            Log::write($e->getTraceAsString());
        }finally{
            $this->execute("commit");
        }
    }
    public function finishRedpack($redpack_id){
//        $this->data()->where("id={$redpocket_id}")->save();
        $data=array();
        $data['finish_time']=time();
        $data['status']=2;

        $result=$this->where("id=".$redpack_id)->data($data)->save();
        if($result){
            return true;
        }else{
            return false;
        }
    }

    public function addRedpackData($redpack_id,$redpack=null){
        try {
            if ($redpack == null) {
                $red = $this->detail($redpack_id);
            } else {
                $red = $redpack;
            }
            $money = $red['money'];
            $num = $red['num'];
            $count = M("RedpackData")->where("redpack_id={$redpack_id}")->count();
            if ($num == $count) return false;
            if(doubleval($money)<1){
                $arr = $this->splitReward($money, $num, rand(100, 1000));
            }else{
                $arr = $this->splitReward_pre($money, $num, rand(100, 1000));
            }


            while (in_array(0, $arr)) {
                if(doubleval($money)<1){
                    $arr = $this->splitReward($money, $num, rand(100, 1000));
                }else{
                    $arr = $this->splitReward_pre($money, $num, rand(100, 1000));
                }
            }
            shuffle($arr);//打乱顺序
            $new_data_list = array();
            foreach ($arr as $one) {
                $data = array();
                $data['redpack_id'] = $redpack_id;
                $data['uid'] = 0;
                $data['nickname'] = '';
                $data['avatarUrl'] = '';
                $data['gender'] = 0;
                $data['money'] = $one;
                $data['add_time'] = 0;
                $data['status'] = 0;
                $new_data_list[] = $data;

            }
            M("RedpackData")->addAll($new_data_list);
            return true;
        }catch (\Think\Exception $e){
            \Think\log::write($e->getTraceAsString());
            return false;
        }
    }
    public $rewardMoney;        #红包金额、单位元
    public $rewardNum;                  #红包数量
    public $scatter;            #分散度值1-10000
    public $rewardArray;        #红包结果集

    public function splitReward_pre($rewardMoney,$rewardNum,$scatter=100){
        $MoneyList=array();
        $baseMoney=$rewardNum*1.00;

        $overplusMoney=$rewardMoney-$baseMoney;
        $overplushList=$this->splitReward($overplusMoney,$rewardNum,$scatter);
        $processCountMoney=0;
        for($i=0;$i<$rewardNum;$i++){
            $MoneyList[]=1.00+$overplushList[$i];
        }

        for($i=0;$i<$rewardNum;$i++){
            $processCountMoney=$processCountMoney+$MoneyList[$i];
        }
        return $MoneyList;
    }

    #执行红包生成算法
    public function splitReward($rewardMoney,$rewardNum,$scatter=100)
    {
        #传入红包金额和数量
        $this->rewardMoney=$rewardMoney;
        $this->rewardNum=$rewardNum;
        $this->scatter=$scatter;
        $this->realscatter=$this->scatter/100;

        /*
         *前言：今天我突然这样一想，比如要把1个红包分给N个人，实际上就是相当于要得到N个百分比数据
         *     条件是这N个百分比之和=100/100。这N个百分比的平均值是1/N。
         *     并且这N个百分比数据符合一种正态分布（多数值比较靠近平均值）
         *观点：微信红包里很多0.01的红包，我觉得这是微信程序里的人为控制，目的是为了防止总红包数超过总额，先分了几个0.01的红包。
         *     不然不管是以随机概率还是正态分布都很难会出现非常多的0.01元红包。
         */

        #我的思路：正如上面说的，比如：1个红包发给5个人，我要得出5个小数，它们的和是1，他们的平均值是1/5
        #计算出发出红包的平均概率值、精确到小数4位。即上面的1/N值。
        $avgRand=round(1/$this->rewardNum,4);

        #红包的向平均数集中的分布正像数学上的抛物线。抛物线y=ax2，|a|越大则抛物线的开口就越小，|a|越小则抛物线的开口就越大,a>0时开口向上，我们这都是正数，就以a>0来考虑吧。
        #程序里的$scatter值即为上方的a，此值除以100，当做100为基准，
        #通过开方(数学里的抛物线模型，开方可缩小变化值)得出一个小数字较多（小数字多即小红包多）的随机分布,据此生成随机数
        $randArr=array();
        while(count($randArr)<$rewardNum)
        {
            $t=round(sqrt(mt_rand(1,10000)/$this->realscatter));
            $randArr[]=$t;
        }


        #计算当前生成的随机数的平均值，保留4位小数
        $randAll=round(array_sum($randArr)/count($randArr),4);

        #为将生成的随机数的平均值变成我们要的1/N，计算一下生成的每个随机数都需要除以的值。我们可以在最后一个红包进行单独处理，所以此处可约等于处理。
        $mixrand=round($randAll/$avgRand,4);

        #对每一个随机数进行处理，并剩以总金额数来得出这个红包的金额。
        $rewardArr=array();
        foreach($randArr as $key=>$randVal)
        {
            $randVal=round($randVal/$mixrand,4);
            $rewardArr[]=round($this->rewardMoney*$randVal,2);
        }

        #对比红包总数的差异、修正最后一个大红包
        sort($rewardArr);
        $rewardAll=array_sum($rewardArr);
        $rewardArr[$this->rewardNum-1]=$this->rewardMoney-($rewardAll-$rewardArr[$this->rewardNum-1]);
//        rsort($rewardArr);
        #对红包进行排序一下以方便在前台图示展示
        $this->rewardArray=$rewardArr;
        return $this->rewardArray;
    }
}