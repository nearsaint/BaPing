<?php
namespace Home\Model;
use \Think\Model;
class UsersIncomeLogModel extends \Think\Model{

    public function getList($mapwhere=array())
    {
        $list = $this->where($mapwhere)->order("id desc")->select();

        return $list;
    }
    public function addIncomeLog($user_id,$redpack_id,$money,$prev_balance,$current_balance,$income_type=0,$trade_no=""){
        $data=array("uid"=>$user_id,'redpack_id'=>$redpack_id,'money'=>$money,'income_type'=>$income_type,'trade_no'=>$trade_no,'memo'=>$trade_no);

            //收入
        $data['current_balance']=$current_balance;
        $data['prev_balance']=$prev_balance;

        $data['memo']="";
        $data['add_time']=time();
        $this->data($data)->add();
    }
    /**
     * @param $user_id
     * @param $type
     * @param $type_rid
     * @param $money
     * @param int $income_type 0为收入，1为提现，2为消费支出
     */
    public function incomeLog($user_id,$redpack_id,$money,$income_type=0,$trade_no=""){
        $data=array("uid"=>$user_id,'redpack_id'=>$redpack_id,'money'=>$money,'income_type'=>$income_type,'trade_no'=>$trade_no,'memo'=>$trade_no);

        $userdao=new \Home\Model\UsersModel();
        $user=$userdao->where("id={$user_id}")->cache(false,3600)->find();
        if($income_type===1) {

            $data['current_balance']=doubleval($user['balance'])-doubleval($money);
            $data['prev_balance']=doubleval($user['balance']);

        }else if($income_type===2){
            //消费
            $data['current_balance']=$user['balance'];
            $data['prev_balance']=$user['balance'];
        }else{
            //收入
            $data['current_balance']=$user['balance']+$money;
            $data['prev_balance']=$user['balance'];
        }
        $data['memo']="";
        $data['add_time']=time();
        $this->data($data)->add();
    }
    public function cashoutLog($user_id,$money){
        $data=array('income_type'=>1,"user_id"=>$user_id,'type'=>0,'type_rid'=>0,'money'=>$money);
        $data['add_time']=time();
        $userdao=new \Home\Model\UsersModel();
        $user=$userdao->where("id={$user_id}")->cache(false,3600)->find();
        $data['current_balance']=$user['balance'];
        $data['prev_balance']=$user['balance']+$money;
        $this->data($data)->add();
    }
}
