<?php
namespace Home\Model;
use \Think\Model;
class OrdersModel extends Model{



    public function getOrderBySN($order_sn){
        return $this->where("order_sn='".$order_sn."'")->find();
    }
    public function findByOrderidAndUpdateSN($order_id){
        $data=array();
        $data['order_sn']=\Org\Util\StringClass::keyGen();
        $this->data($data)->where("id={$order_id}")->save();
        $order=$this->where("id={$order_id}")->find();
        return $order;
    }


    public function finishOrder($order_id,$transid,$out_tran_id,$money,$pay_way,$mch_id="",$openid=""){
        $data['mch_id']=$mch_id;
        $data['tran_id']=$transid;
        $data['out_tran_id']=$out_tran_id;
        $data['pay_way']=$pay_way;
        $data['pay_money']=$money;
        $data['openid']=$openid;
        $data['status']=1;
        $data['work_status']=0;
        $data['pay_time']=time();
        $this->data($data)->where("id={$order_id}")->save();
        $return=$this->where("id={$order_id}")->cache(false,3600)->find();

        return $return;
    }
    public function makeOrder($money,$blocked_money,$uid,$redpack_id){

        $data=array();
        $data['order_sn']=\Org\Util\StringClass::keyGen();
        $data['uid']=$uid;
        $data['redpack_id']=$redpack_id;
        $data['order_time']=time();
        $data['status']=0;



        if($money>$blocked_money){
            $data['total_money']=$money;
            $data['money']=$money-$blocked_money;
            if($data['money']<0){
                return false;
            }
            $data['balance']=$blocked_money;
        }else{
            $data['money']=$money;
            $data['total_money']=$money;
        }


        $id=$this->data($data)->add();
        if($id>0) {
            $data['id'] = $id;
            return $data;
        }else{
            return false;
        }
    }
}
