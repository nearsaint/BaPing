<?php
namespace Home\Model;
use \Think\Model;
class UsersModel extends Model
{
    private $cache_key='wx_apps_user_';
    public function findByOpenid($openid){
        $user=$this->where("openid='{$openid}'")->find();
        if($user) {
            $user['nickname'] = unicode2emoji($user['nickname']);
//            $user['avatarUrl'] = str_replace('/0','/96',$user['avatarUrl'] );
        }
        return $user;
    }
    public function findByuid($uid){
        $user=$this->where("id='{$uid}'")->find();
        if($user) {
            $user['nickname'] = unicode2emoji($user['nickname']);
//            $user['avatarUrl'] = str_replace('/0','/96',$user['avatarUrl'] );
        }
        return $user;
    }
    public function setLoginUser($user){
        session('user', $user);
        S($this->cache_key.$user['id'],$user,3600);
    }
    public function getLoginUser($uid){
        return S($this->cache_key.$uid);
    }
    public function addIncome($user_id,$money){
        M('Users')->where("id=" . $user_id)->setInc('balance', $money);
        M('Users')->where("id={$user_id}")->cache(false,3600)->find(); //清除缓存
    }

    /**
     * @param $uid
     * @param $order_id
     * @return bool
     * 返还冻结金额
     */
    public function unblock_balance($uid,$order_id){
        $block_money=M("Orders")->where("uid=$uid and id=$order_id and status<>-1")->getField("balance");

        if($block_money==0||$block_money==false){
            M("Orders")->where("id=$order_id")->setField("status",-1);
            return true;
        }
        $user=$this->findByuid($uid);
        if($block_money<=$user['blocked_balance']) {
            $result = $this->where("id=$uid")->setDec("blocked_balance", $block_money);
            if($result) {
                $result = $this->where("id=$uid")->setInc("balance", $block_money);
                M("Orders")->where("id=$order_id")->setField("status",-1);
            }else{
                return false;
            }

        }
        return $result;
    }
    /**
     * @param $uid
     * @param $order_money 订单金额
     * @return mix 返回已冻结的金额
     *
     */
    public function block_balance($uid,$order_money){
        $tableName=$this->getTableName();
        $user=$this->where("id={$uid}")->find();

        if($user['balance']<$order_money){
            $block_money=$user['balance'];
        }else{
            $block_money=$order_money;
        }
        $result = $this->execute("update {$tableName} set blocked_balance=blocked_balance+{$block_money} , balance=balance-{$block_money} where id={$uid} limit 1");
        if($result){
            return $block_money;
        }else{
            return false;
        }
    }
}