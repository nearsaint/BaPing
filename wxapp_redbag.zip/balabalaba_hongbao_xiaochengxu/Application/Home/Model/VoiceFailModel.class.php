<?php
namespace Home\Model;
use \Think\Model;
class VoiceFailModel extends Model
{
    //$voice_url,$voice_source_filename,$voice_filename,$voice_duration,$voice_file_size,$voice_bit_rate,$voice_txt,$redpack_id,$uid,$avatarUrl,$gender,$nickname

    public function addAndUpdateVoice($data){
        $rec=$this->where("redpack_id={$data['redpack_id']} and uid={$data['uid']}")->find();
        $dao=new UsersModel();
        $user=$dao->findByuid($data['uid']);
        $data['nickname']=base64_encode($user['nickname']);
        $data['avatarUrl']=$user['avatarUrl'];
        $data['gender']=$user['gender'];
        if($rec){
            $this->data($data)->where("id=".$rec['id'])->save();
        }else{
            $this->data($data)->add();
        }
    }
    public function addVoice1($voice_url,$voice_source_filename,$voice_filename,$voice_duration,$voice_file_size,$voice_bit_rate,$voice_txt,$redpack_id,$uid,$avatarUrl,$gender,$nickname){
        $rec=$this->where("redpack_id={$redpack_id} and uid={$uid}")->find();
        if($rec){

        }

    }


}