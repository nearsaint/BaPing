ffprobe -v quiet -print_format json -show_format -show_streams 595b5708ec4f3.wav

ffmpeg.exe -i /home/wwwroot/vrp.balabalafun.cn/0.wav -ar 8000 -ab 12.2k -ac 1 /home/wwwroot/vrp.balabalafun.cn/0.amr

./configure --enable-gpl --enable-version3 --enable-nvenc --enable-avisynth --enable-bzlib --enable-fontconfig --enable-gnutls --enable-iconv --enable-libass --enable-libbluray --enable-libbs2b --enable-libcaca --enable-libfreetype --enable-libgme --enable-libgsm --enable-libilbc --enable-libmodplug --enable-libmfx --enable-libmp3lame --enable-libopencore-amrnb --enable-libopencore-amrwb --enable-libopenjpeg --enable-libopus --enable-librtmp --enable-libschroedinger --enable-libsnappy --enable-libsoxr --enable-libspeex --enable-libtheora --enable-libtwolame --enable-libvidstab --enable-libvo-amrwbenc --enable-libvorbis --enable-libvpx --enable-libwavpack --enable-libwebp --enable-libx264 --enable-libx265 --enable-libxavs --enable-libxvid --enable-libzimg --enable-lzma --enable-zlib

ffmpeg -f s16le -i /home/wwwroot/vrp.balabalafun.cn/0.pcm -y -ar 8000 -ab 12.2k -ac 1 /home/wwwroot/vrp.balabalafun.cn/0.wav

ffmpeg -f s16le -i /home/wwwroot/vrp.balabalafun.cn/0.pcm -y -ar 8000 -ab 12.2k -ac 1 /home/wwwroot/vrp.balabalafun.cn/0.amr

ffmpeg -v quiet -y -f s16le -ar 8000 -ac 12.2k -i /home/wwwroot/vrp.balabalafun.cn/0.pcm /home/wwwroot/vrp.balabalafun.cn/0.amr


==============================

/home/silk_v3/silk/decoder /home/wwwroot/vrp.balabalafun.cn/0.silk /home/wwwroot/vrp.balabalafun.cn/0.pcm -Fs_API 8000

/usr/bin/ffmpeg -y -f s16le -ar 8000 -ac 1 -i /home/wwwroot/vrp.balabalafun.cn/0.pcm -ab 12.2k -ar 8000 -ac 1 /home/wwwroot/vrp.balabalafun.cn/0.amr  //先pcm转成amr